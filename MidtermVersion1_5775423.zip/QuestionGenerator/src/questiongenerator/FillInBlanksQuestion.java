/*
 * @author 5775423
 * 
 * Title: MidtermVersion1_5775423.zip
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads 2 files containing questions, asks the user
 *               those questions, and displays how many of the user's answers
 *               were correct or not.
 */
package questiongenerator;

import java.util.ArrayList;

public class FillInBlanksQuestion extends Question
{
    //instance variable
    private String correctAnswer;
    
    //constructor
    public FillInBlanksQuestion (String aQuestion, String rightAnswer)
    {//A FillInBlanks question will have underscores indicating the multi-part answer
        super(aQuestion);
        correctAnswer = rightAnswer;
       
    }
    //getter
    public String getAnswer()
    {
        return correctAnswer;
    }
    //setter
    public void setAnswer(String anAnswer)
    {
        this.correctAnswer = anAnswer;
    }
    
    //Task 0: 
    //Add the missing method here:
     // if (userAnswer.equalsIgnoreCase(correctAnswer))
     //       return true;  
     //    else
     //        return false;
     
    public boolean checkQuestion(String userAnswer)
    {
        if(userAnswer.equalsIgnoreCase(correctAnswer))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
     
    public String toString()
    {
       //Task 1:  Invoke the super class' toString() and then the type of question it is (Fill inthe Blank or True/False)
       //specific to the subclass) ;    
        return super.toString() + " - Fill In The Blank Question: ";
    }
    
}
