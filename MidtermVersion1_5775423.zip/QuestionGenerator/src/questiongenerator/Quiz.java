/*
 * @author 5775423
 * 
 * Title: MidtermVersion1_5775423.zip
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads 2 files containing questions, asks the user
 *               those questions, and displays how many of the user's answers
 *               were correct or not.
 */
package questiongenerator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Quiz 
{
    //global counter variables
    int numberCorrectTotal;
    int numberIncorrectTotal;
    
    //Task #1 - Define an arrayList, myQuestions,  of GradableQuestions type
    public ArrayList<GradableQuestions> myQuestions = new ArrayList<GradableQuestions>();
    
    //global keyboard object
    public Scanner keyboard = new Scanner(System.in);
    
    public static void main(String[] args)
    {
        //instantiate the driver
        Quiz myQuiz = new Quiz();
        
        myQuiz.createQuestions();
        myQuiz.displayAndCheckQuestions();
        myQuiz.summarizeResults();
    }
    
    //this method reads each file containing questions and their correct answers
    public void createQuestions()
    {
        //create variables for the reading the file
        File aTFFile;
        File aFIBFile;
        Scanner inTFFile = null;
        Scanner inFIBFile = null;
        TrueFalseQuestion aTFQuestion;
        FillInBlanksQuestion aFIBQuestion;
        String question, correctAnswer = "", fileName = "";
        boolean rightAnswer;
        boolean invalidFile = true;
        //Task #2:
        //Add a loop that will contain the try-catch blocks below, and will continue until a valid file name is entered
        //Add a finally clause, but check that the file was created before closing it
        
        //Ask user to enter name of 2 input files (inputTrueFalse.txt)
        //Use a try-catch-finally block to handle the fileNotFound condition
        //Open the input file, stored in the project's directory
        //read using another loop the first file until the end of the file
        //for each record read, create a TrueFalse object, and put inside arrayList of GradableQuestion
        do
        {
            try
            {
                //ask for the name of the true false file and store it
                System.out.print("What is the name of the file with True/False Questions: ");
                fileName = keyboard.next();
                
                //open file and read file
                aTFFile = new File(fileName);
                inTFFile = new Scanner(aTFFile);
                //if the file is valid, dont loop again
                invalidFile = false;
                
                //while the file still has contents to read
                while(inTFFile.hasNext())
                {
                    question = inTFFile.next();
                    rightAnswer = inTFFile.nextBoolean();
                    
                    //store into the corresponding object
                    aTFQuestion = new TrueFalseQuestion(question, rightAnswer);
                    
                    //add the object to the arraylist
                    myQuestions.add(aTFQuestion);
                }
            }
            //catch file not found exception and loop again
            catch(FileNotFoundException e)
            {
                invalidFile = true;
            }
            //finally, if the file exists, close the file
            finally
            {
                if(!invalidFile)
                {
                    inTFFile.close();
                }
            }
        }while(invalidFile); //loop again if the file is still invalid
               
        //Task #3:
         //Use another try-catch-finally block to handle the fileNotFound condition (inputFillInBlank.txt) 
        //Open the input file, stored in the project's directory
        //read using another loop the second file until the end of the file
        //for each record read, create a FillInBlanksQuestion object, and put inside arrayList of GradableQuestion
        
        //prepare to loop again
        invalidFile = true;
        do
        {
            try
            {
                //ask for the name of the fill in the blank file and store it
                System.out.print("What is the name of the file with Fill In The Blank Questions: ");
                fileName = keyboard.next();
                
                //open and read file
                aFIBFile = new File(fileName);
                inFIBFile = new Scanner(aFIBFile);
                //if file was valid, dont loop again
                invalidFile = false;
                
                //continue reading while there are still contents inside
                while(inFIBFile.hasNext())
                {
                    question = inFIBFile.next();
                    correctAnswer = inFIBFile.nextLine();
                    
                    //store into the corresponding object
                    aFIBQuestion = new FillInBlanksQuestion(question, correctAnswer.trim());
                    
                    //add the object to the arraylist
                    myQuestions.add(aFIBQuestion);
                }
            }
            //catch file not found exception and loop again
            catch(FileNotFoundException e)
            {
                invalidFile = true;
            }
            //finally, if the file exists, close the file
            finally
            {
                if(!invalidFile)
                {
                    inFIBFile.close();
                }
            }
        }while(invalidFile); //loop again if the file is still invalid
    }
        //this method asks questions and checks answers for each item in the arraylist
        public void displayAndCheckQuestions()
        {
            //Task #4:
            //Write a loop that will polymorphically display the question, ask the user for an answer, 
            // and then polymorphically check the question.
            // if True ----> add 1 to user's correct count
            //    Otherwise ---> add 1 to user's incorrect count
            String userAnswer = "";
            boolean result;
            
            keyboard.nextLine();
            //for loop to ask questions and check answers for each item in arraylist
            for(int i = 0; i < myQuestions.size(); i++)
            {
                //print each question and store the user's answer to it
                System.out.print(myQuestions.get(i));
                userAnswer = keyboard.nextLine();
                
                //check if the answer is right
                result = myQuestions.get(i).checkQuestion(userAnswer);
                
                //if the answer was right, add 1 to the correct counter total
                if(result == true)
                {
                    numberCorrectTotal++;
                }
                //if the answer was wrong, add 1 to the incorrect counter total
                else if(result == false)
                {
                    numberIncorrectTotal++;
                }
            }
        }
   
    //this method displays the counter variables
    public void summarizeResults()
    {
        // display a summary of all the correct and incorrect answers given by the user on the Quiz, by vetted and trial categories
        System.out.println("\nThe number of questions answered correctly are " + numberCorrectTotal);
        System.out.println("The number of questions answered incorrectly are: " + numberIncorrectTotal);
    }
}
