/*
 * @author 5775423
 * 
 * Title: MidtermVersion1_5775423.zip
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads 2 files containing questions, asks the user
 *               those questions, and displays how many of the user's answers
 *               were correct or not.
 */
package questiongenerator;

import java.util.ArrayList;

public class TrueFalseQuestion extends Question
{
    //instance variable
    private boolean correctAnswer;
    
    //constructor
    public TrueFalseQuestion(String aQuestion, boolean rightAnswer)
    {
        super(aQuestion);  
        correctAnswer = rightAnswer;
    }
    
    //getter
     public boolean getAnswer()
     {
         return correctAnswer;
     }
    //setter
     public void setAnswer(Boolean anAnswer)
     {
         this.correctAnswer = anAnswer;
     }
     //create the polymorphic method to check if the answer was correct
     public boolean checkQuestion(boolean userAnswer)
     {
         if (userAnswer == correctAnswer)
             return true;
         else
             return false;        
     }
    
   //Task 0:  
   //Add the missing call to a method here:
   // if (userAnswer.equalsIgnoreCase("true"))
   //          return checkQuestion(true);
   //      else 
   //          return checkQuestion(false);
     public boolean checkQuestion(String userAnswer)
     {
         //convert answer to boolean
         if(userAnswer.equalsIgnoreCase("true"))
         {
             return checkQuestion(true);
         }
         else
         {
             return checkQuestion(false);
         }
     }
     
    public String toString()
    {
        //Task 1:  Invoke the super class' toString() and then the type of question it is (Fill inthe Blank
       //specific to the subclass
        return super.toString() + " - True/False Question: ";
    }
}
