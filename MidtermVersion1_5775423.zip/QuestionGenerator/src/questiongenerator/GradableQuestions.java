/*
 * @author 5775423
 * 
 * Title: MidtermVersion1_5775423.zip
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads 2 files containing questions, asks the user
 *               those questions, and displays how many of the user's answers
 *               were correct or not.
 */
package questiongenerator;

public interface GradableQuestions 
{
    //polymorphic method
    public boolean checkQuestion(String userAnswer);
    
}
