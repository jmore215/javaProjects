/*
 * @author 5775423
 * 
 * Title: MidtermVersion1_5775423.zip
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads 2 files containing questions, asks the user
 *               those questions, and displays how many of the user's answers
 *               were correct or not.
 */
package questiongenerator;

import java.util.ArrayList;

public abstract class Question implements GradableQuestions
{
    //instance variable
    private String questionText;
    
    //constructor
    public Question(String aQuestionText)
    {
        questionText = aQuestionText;
    }
    //setter
    public void setQuestionText(String aText)
    {
        questionText = aText;
    }
    //getter
    public String getQuestionText()
    {
        return questionText;
    }
    //toString
    public String toString()
    {
        return questionText ;
    }
}
