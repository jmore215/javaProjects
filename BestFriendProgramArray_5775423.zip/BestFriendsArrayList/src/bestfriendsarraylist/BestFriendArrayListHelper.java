/*
 * @author 5775423
 * 
 * Title: BestFriendProgramArray_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program creates a phonebook of contact info and
 *                  manipulates it
 */

package bestfriendsarraylist;

//import ArrayList and Scanner
import java.util.Arrays;
import java.util.Scanner;

public class BestFriendArrayListHelper 
{
    //create array called myBFFs
    BestFriend[] myBFFs = new BestFriend[10];
    
    //create a global keyboard object
    Scanner keyboard = new Scanner(System.in);
    
    //create global variables for friend contact info
    String firstName, lastName, nickname, cellphone, email;
    
    //global int variable for size
    int currentSize = 0;
    
    //method to add a friend
    public boolean addAFriend()
    {
        //ask for first name and store it
        System.out.print("Enter your friend's first name: ");
        firstName = keyboard.nextLine();
        
        //ask for last name and store it
        System.out.print("\nEnter your friend's last name: ");
        lastName = keyboard.nextLine();
        
        //ask for nickname and store it
        System.out.print("\nEnter your friend's nickname: ");
        nickname = keyboard.nextLine();
        
        //ask for cellphone number and store it
        System.out.print("\nEnter your friend's cellphone number: ");
        cellphone = keyboard.nextLine();
        
        //ask for email and store it
        System.out.print("\nEnter your friend's email: ");
        email = keyboard.nextLine();
        
        //create an object to store all information
        BestFriend myFriend = new BestFriend(firstName, lastName, nickname, cellphone, email);
        
        //add object of a new friend to the array
        if(currentSize < myBFFs.length)
        {
            //add the object to the array
            myBFFs[currentSize] = myFriend;
            
            //increment currentSize for each new friend added
            currentSize++;
        }
        else
        {
            //double size of array using Array.copyOf()
            myBFFs = Arrays.copyOf(myBFFs, 2 * myBFFs.length);
        }
        
        return true;
    }
    
    //method to change a friend's info
    public void changeAFriend()
    {
        //int used for finding if the friend is in the array
        int foundFlag = 0;
        
        //ask the user for info to search using first name
        System.out.print("\nEnter the first name of the friend you want to change: ");
        firstName = keyboard.nextLine();
        
        //ask the user for info to search using last name
        System.out.print("\nEnter the last name of the friend you want to change: ");
        lastName = keyboard.nextLine();
        
        //ask the user for info to search using nickname
        System.out.print("\nEnter the nickname of the friend you want to change: ");
        nickname = keyboard.nextLine();
        
        //create a BFF object with the info to find
        BestFriend chgBFF = new BestFriend(firstName, lastName, nickname);
        
        //use contains method to see if chgBFF is in array and store result
        foundFlag = find(chgBFF);
        
        //if myBFFs does contain chgBFF...
        if(foundFlag != -1)
        {
            //display friend found message
            System.out.println("\nFRIEND FOUND");
            
            //ask the user what to change the first name to
            System.out.print("\nWhat is the new first name you want it changed to? ");
            firstName = keyboard.nextLine();
            
            //ask the user what to change the last name to
            System.out.print("\nWhat is the new last name you want it changed to? ");
            lastName = keyboard.nextLine();
            
            //ask the user what to change the nickname to
            System.out.print("\nWhat is the new nickname you want it changed to? ");
            nickname = keyboard.nextLine();
            
            //ask the user what to change the phone number to
            System.out.print("\nWhat is the new phone number you want it changed to? ");
            cellphone = keyboard.nextLine();
            
            //ask the user what to change the email to
            System.out.print("\nWhat is the new email you want it changed to? ");
            email = keyboard.nextLine();
            
            //set the chgBFF object to the new information the user entered
            chgBFF.setFirstName(firstName);
            chgBFF.setLastName(lastName);
            chgBFF.setNickName(nickname);
            chgBFF.setCellPhone(cellphone);
            chgBFF.setEmail(email);
            
            //set the object to the index location
            myBFFs[foundFlag] = chgBFF;
            
            //display the friend has been changed message
            System.out.println("\nFRIEND CHANGED");
        }
        
        //if myBFFs does not contain chgBFF...
        else if(foundFlag == -1)
        {
            //display friend not found message
            System.out.println("\nFRIEND NOT FOUND");
        }
    }
    
    //method to remove a friend from the array
    public void removeAFriend()
    {
        //int used for finding if the friend is in the array
        int foundFlag = 0;
        //string variable to get user answer
        String answer;
        
        //ask the user for info to search using first name
        System.out.print("\nEnter the first name of the friend you want to remove: ");
        firstName = keyboard.nextLine();
        
        //ask the user for info to search using last name
        System.out.print("\nEnter the last name of the friend you want to remove: ");
        lastName = keyboard.nextLine();
        
        //ask the user for info to search using nickname
        System.out.print("\nEnter the nickname of the friend you want to remove: ");
        nickname = keyboard.nextLine();
        
        //create a BFF object with the info to find and remove
        BestFriend removeBFF = new BestFriend(firstName, lastName, nickname);
        
        //use contains method to see if removeBFF is in array and store result
        foundFlag = find(removeBFF);
        
        //if myBFFs does contain removeBFF...
        if(foundFlag != -1)
        {
            //display friend found message
            System.out.println("\nFRIEND FOUND");
            
            //ask if the user really wants to remove the friend
            System.out.print("\nAre you sure you want to remove this friend? ");
            answer = keyboard.nextLine();
            
            //if the answer is yes..
            if(answer.equalsIgnoreCase("yes"))
            {
                //remove the friend at the index and move up other objects 
                for(int i = foundFlag; i < currentSize; i++)
                {
                    myBFFs[i] = myBFFs[i + 1];
                }
                currentSize--;
                myBFFs[currentSize] = null;
                //display friend removed message
                System.out.println("\nFRIEND REMOVED");
            }
        }
        //else if myBFFs does not contain removeBFF
        else if(foundFlag == -1)
        {
            //display friend not found message
            System.out.println("\nFRIEND NOT FOUND");
        }
    }
    
    //method to display all friends or a specific friend
    public void displayAFriend()
    {
        //int used for finding if the friend is in the array
        int foundFlag = 0;
        //int variable for user choice
        int choice;
        
        //do while to make sure answer is either 1 or 2
        do
        {
            //display choice options
            System.out.print("\nWould you like to... \n1.) Show the entire phonebook?\n2.) Show a specific friend?\n");
            choice = keyboard.nextInt();
            
            //if statement in case user enters invalid input
            if(choice < 1 || choice > 2)
            {
                //display invalid message
                System.out.println("Invalid! Please enter either 1 or 2.");
            }
        }while(choice < 1 || choice > 2);
        
        keyboard.nextLine();
        
        //if the user chooses to display all contacts...
        if(choice == 1)
        {
            System.out.println("-----Contacts-----");
            //for loop to print values in array
            for(int i = 0; i < myBFFs.length; i++)
            {
                System.out.println("#" + i + ": " + myBFFs[i]);
            }
            System.out.println("------------------");
        }
        //else if the user chooses to display a specific friend
        else if(choice == 2)
        {
            //ask user for first name of friend
            System.out.print("\nWhat is your friend's first name? ");
            firstName = keyboard.nextLine();
            
            //ask user for last name of friend
            System.out.print("\nWhat is your friend's last name? ");
            lastName = keyboard.nextLine();
            
            //ask user for nickname of friend
            System.out.print("\nWhat is your friend's nickname? ");
            nickname = keyboard.nextLine();
            
            //create a BFF object with the info to find and display
            BestFriend findBFF = new BestFriend(firstName, lastName, nickname);
            
            //use contains method to see if findBFF is in array and store result
            foundFlag = find(findBFF);
            
            //if myBFFs does contain findBFF...
            if(foundFlag != -1)
            {
                //display friend found message
                System.out.println("\nFRIEND FOUND");
                
                //print array item at the index
                System.out.println(myBFFs[foundFlag]);
            }
            //else if friend not found...
            else if(foundFlag == -1)
            {
                //display friend not found message
                System.out.println("\nFriend is NOT found in PhoneBook.");
            }
        }
    }
    
    //method to find an object in the array
    public int find(BestFriend findBFF)
    {
        int index = 0;
        boolean found = false;
        
        //find using while loop to look through array
        while(index < myBFFs.length && index < currentSize 
                && found == false)
        {
            //if it was found at an index...
            if(findBFF.equals(myBFFs[index]))
            {
                found = true;
            }
            //else it was not found in any index
            else
            {
                //increment index
                index++;
            }
        }
        //if it was found...
        if(found == true)
        {
            //return the index it was found in the array
            return index;
        }
        else
        {
            //return that it was not found in the array
            return -1;
        }
    }
}
