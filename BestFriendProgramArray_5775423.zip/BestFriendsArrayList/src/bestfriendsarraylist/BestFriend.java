/*
 * @author 5775423
 * 
 * Title: BestFriendProgramArray_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program creates a phonebook of contact info and
 *                  manipulates it
 */

package bestfriendsarraylist;

import java.util.Objects;

public class BestFriend 
{
    //instance variables
    private String firstName;
    private String lastName;
    private String nickName;
    private String cellPhone;
    private String email;

    //constructor
    public BestFriend(String firstName, String lastName, String nickName, String cellPhone, String email) 
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.nickName = nickName;
        this.cellPhone = cellPhone;
        this.email = email;
    }
    
    //constructor
    public BestFriend(String firstName, String lastName, String nickName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.nickName = nickName; 
    }
    
    //getters and setters
    public String getFirstName() 
    {
        return firstName;
    }

    public void setFirstName(String firstName) 
    {
        this.firstName = firstName;
    }

    public String getLastName() 
    {
        return lastName;
    }

    public void setLastName(String lastName) 
    {
        this.lastName = lastName;
    }

    public String getNickName() 
    {
        return nickName;
    }

    public void setNickName(String nickName) 
    {
        this.nickName = nickName;
    }

    public String getCellPhone() 
    {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) 
    {
        this.cellPhone = cellPhone;
    }

    public String getEmail() 
    {
        return email;
    }

    public void setEmail(String email) 
    {
        this.email = email;
    }
    
    //toString to return values
    @Override
    public String toString() 
    {
        return firstName + " " + lastName + " // Nickname: " + nickName + " // Phone Number: " + cellPhone + " // Email: " + email;
    }

   

    @Override
    public boolean equals(Object obj) 
    {
        final BestFriend other;
        
        if (this == obj) 
        {
            return true;
        }
        if (obj == null) 
        {
            return false;
        }
       
        if (obj instanceof BestFriend)
        {
           other = (BestFriend) obj;
               
        }
        else
        {
            return false;
        }
        
        if ( (this.firstName.equals(other.firstName)) &&
              (this.lastName.equals(other.lastName)) &&  
              (this.nickName.equals(other.nickName)))
            return true;
        else
            return false;
    }
}
