/*
 * @author 5775423
 * 
 * Title: BestFriendProgramArray_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program creates a phonebook of contact info and
 *                  manipulates it
 */

package bestfriendsarraylist;

//import scanner
import java.util.Scanner;

public class BestFriendsArrayList 
{
    public static void main(String[] args) 
    {
        //instantiate helper class one time
        BestFriendArrayListHelper myHelper = new BestFriendArrayListHelper(); 
        
        //set userChoice equal to 0
        int userChoice = 0;
        
        //create a scanner object
        Scanner keyboard = new Scanner(System.in);

        //do while loop to display menu with sout
        do
        {
            //get user's input
            System.out.println("\n1.) Add Best Friends\n2.) Change Best Friends\n3.) Remove Best Friends\n4.) Display Best Friends\n5.) Exit");
            userChoice = keyboard.nextInt();
            
            //switch statement to evaluate user input
            switch(userChoice)
            {
                //inside case statements, call helper methods
                case 1:
                    //add a friend
                    myHelper.addAFriend();
                    break;
                case 2:
                    //change a friend
                    myHelper.changeAFriend();
                    break;
                case 3:
                    //remove a friend
                    myHelper.removeAFriend();
                    break;
                case 4:
                    //display a friend
                    myHelper.displayAFriend();
                    break;
                case 5:
                    //exit
                    System.out.println("\nGoodbye!");
                    break;
                default:
                    //invalid message
                    System.out.println("\nInvalid! Please enter a number from 1 to 5.");
            }
        }while(userChoice != 5); //stop loop when user enters 5
    }
}
