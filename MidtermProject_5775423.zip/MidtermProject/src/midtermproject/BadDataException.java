/*
 * @author 5775423
 * 
 * Title: MidtermProject_5775423
 * Semester: COP38054 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads a file of courses. The user can sort the
 *                courses, search for a specific course, or add another course        
 */
package midtermproject;


public class BadDataException extends RuntimeException
{
    //default constructor using constructor of super
    public BadDataException()
    {
        super();
    }
    
    //non-default constructor for message
    public BadDataException(String message)
    {
        super(message);
    }
}
