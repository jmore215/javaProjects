/*
 * @author 5775423
 * 
 * Title: MidtermProject_5775423
 * Semester: COP38054 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads a file of courses. The user can sort the
 *                courses, search for a specific course, or add another course        
 */
package midtermproject;


public class CollegeCourse implements Comparable<CollegeCourse>
{
    //instance variables
    private String courseName;
    private int courseCredits;
    private String courseTitle;

    //constructor
    public CollegeCourse(String courseName, int courseCredits, String courseTitle) {
        this.courseName = courseName;
        this.courseCredits = courseCredits;
        this.courseTitle = courseTitle;
    }
    
    //getters
    public String getCourseName() {
        return courseName;
    }

    public int getCourseCredits() {
        return courseCredits;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    //setters
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setCourseCredits(int courseCredits) {
        this.courseCredits = courseCredits;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }
    
    //toString
    @Override
    public String toString() {
        return "CollegeCourse{" + "courseName=" + courseName + ", courseCredits=" + courseCredits + ", courseTitle=" + courseTitle + '}';
    }
    
    //compareTo to sort by course name 
    public int compareTo(CollegeCourse aCourse)
    {
        return (this.courseName.compareTo(aCourse.courseName));
    }
    
}
