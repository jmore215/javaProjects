/*
 * @author 5775423
 * 
 * Title: MidtermProject_5775423
 * Semester: COP38054 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads a file of courses. The user can sort the
 *                courses, search for a specific course, or add another course        
 */
package midtermproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MidtermProject 
{
    //global keyboard object and global arraylist of courses
    public Scanner keyboard = new Scanner(System.in);
    public ArrayList<CollegeCourse> catalog = new ArrayList<CollegeCourse>();
    
    public static void main(String[] args) 
    {
        int choice;
        
        //instantiate the driver
        MidtermProject myMid = new MidtermProject();
        
        //call method to display menu and store answer
        choice = myMid.displayMenu();
        
        //do while to keep looping until user exits
        do
        {
            //switch user choice for different menu options
            switch(choice)
            {
                //for each case, call the corresponding method and display
                //  menu again
                case 0:
                    myMid.inputFileAndPrint();
                    choice = myMid.displayMenu();
                    break;
                case 1:
                    myMid.sortByCourseName();
                    choice = myMid.displayMenu();
                    break;
                case 2:
                    myMid.sortByCourseTitle();
                    choice = myMid.displayMenu();
                    break;
                case 3:
                    myMid.searchByCourseName();
                    choice = myMid.displayMenu();
                    break;
                case 4:
                    myMid.searchByCourseTitle();
                    choice = myMid.displayMenu();
                    break;
                case 5:
                    myMid.addCourse();
                    choice = myMid.displayMenu();
                    break;
            }
        }while(choice != 6);
    }
    
    //this method displays the menu options and validates user choice
    public int displayMenu()
    {
        int userChoice = 0;
        boolean validChoice = true;
       
       //do while to keep looping till user choice is valid
       do
       {
        try
        {
            //print possible menu options
            System.out.println("0. Input File, Print Contents"
                    + "\n1. Sort & Print by Course Name"
                    + "\n2. Sort & Print by Course Title"
                    + "\n3. Search by Course Name"
                    + "\n4. Search by Course Title"
                    + "\n5. Add Course to Catalog File"
                    + "\n6. Quit");
            //store user answer
            userChoice = keyboard.nextInt();
            
            //dont loop again
            validChoice = true;
            
            //error message if the error message was out of range
            if(userChoice < 0 || userChoice > 6)
            {
                System.out.println("Invalid Number! Enter a number from 0 to 6.");
                //loop again
                validChoice = false;
            }
            //goodbye message if the choice was six
            else if(userChoice == 6)
            {
                System.out.println("Goodbye!!!");
            }
        }
        //catch if the user enters anything besides an integer
        catch(InputMismatchException e)
        {
            //error message
            System.out.println("Invalid Input! Enter a number from 0 to 6.");
            //loop again
            validChoice = false;
            //exit buffer
            keyboard.nextLine();
        }
       }while(!validChoice);
        
        return userChoice;
    }
    
    //this method reads the input file of courses and stores them into the
    // global arraylist
    public void inputFileAndPrint()
    {
        String fileName = "";
        File aFile = null;
        Scanner inFile = null;
        boolean tryAgain = true;
        CollegeCourse aCourse;
        String prefix = "",courseNumber = "", courseName, courseTitle;
        int credit;
       
       //do while to loop again till the file has been read and processed
       do
       {
        try
        {
            //ask for the name of the file and store it
            System.out.print("What is the name of the file? ");
            fileName = keyboard.next();
            
            //file and scanner to read file
            aFile = new File(fileName);
            inFile = new Scanner(aFile);
            
            //while loop to read contents
            while(inFile.hasNext())
            {
                prefix = inFile.next();
                courseNumber = inFile.next();
                credit = inFile.nextInt();
                courseTitle = inFile.nextLine();
                
                //concatenate course name by using the prefix and courseNumber
                courseName = prefix + " " + courseNumber;
                
                //store into course object
                aCourse = new CollegeCourse(courseName, credit, courseTitle.trim());
                
                //add the course to the arraylist
                catalog.add(aCourse);
            }
            //once everything is complete, dont loop again
            tryAgain = false;
        }
        //various catches for exceptions
        catch(FileNotFoundException e)
        {
            System.out.println("File Not Found! Enter a valid file name. \n(Enter SCISCourses2(1).txt for file input)");
            keyboard.nextLine();
        }
        catch(NumberFormatException e)
        {
            System.out.println("Number Format Exception!");
        }
        catch(InputMismatchException e)
        {
            System.out.println("Input Mismatch Exception!");
        }
        catch(IndexOutOfBoundsException e)
        {
            System.out.println("Index Out Of Bounds Exception!");
        }
        catch(Exception e)
        {
            System.out.println("Exception was caught!");
        }
        //finally to close file if it exists
        finally
        {
            if(aFile.exists())
            {
                inFile.close();
            }
        }
       }while(tryAgain);
    }
    
    //this method sorts the arraylist by course name
    public void sortByCourseName()
    {
        //call the sort method
        Collections.sort(catalog);
        
        //for loop to print the sorted arraylist
        System.out.println("******************Catalog by Course Name******************");
        for(int i = 0; i < catalog.size(); i++)
        {
            System.out.println(i + " " + catalog.get(i));
        }
        System.out.println("**********************************************************");
    }
    
    //this method sorts the arraylist by course title
    public void sortByCourseTitle()
    {
        //call the sort method and use the comparator class
        Collections.sort(catalog, new ComparatorByCourseTitle());
        
        //for loop to print the sorted arraylist
        System.out.println("******************Catalog by Course Title******************");
        for(int i = 0; i < catalog.size(); i++)
        {
            System.out.println(catalog.get(i));
        }
        System.out.println("**********************************************************");
    }
    
    //this method searches the arraylist by looking for the desired course name
    public void searchByCourseName()
    {
        //sort the arraylist by course name first
        Collections.sort(catalog);
        
        String searchName = "";
        
        keyboard.nextLine();
        
        //ask for the course name to search for and store it
        System.out.print("What course name do you want to search by? ");
        searchName = keyboard.nextLine();
        
        //create a search object of a course
        CollegeCourse searchCourseName = new CollegeCourse(searchName, 0, "");
        
        //use binary search to search for the index the course is at
        int searchIndex = Collections.binarySearch(catalog, searchCourseName);
        //display the whole course object if found
        if (searchIndex >= 0)
        {
            System.out.println("Here is the entire object for " + searchName);
            System.out.println(catalog.get(searchIndex));
        }
        //if the course returns -1, then print that the course was not found
        else
        {
            System.out.println("Sorry, your desired course was not found: " + searchName);
        }
    }
    
    //this method searches the arraylist by looking for the desired course title
    public void searchByCourseTitle()
    {
        //create arraylist for course title indexes
        ArrayList<Integer> indexes = new ArrayList<Integer>();
        
        //sort the arraylist by course title
        Collections.sort(catalog, new ComparatorByCourseTitle());
        
        String searchTitle = "";
        
        keyboard.nextLine();
        
        //ask what course title to search by
        System.out.print("What course title do you want to search by? ");
        searchTitle = keyboard.nextLine();
        
        //create a search object
        CollegeCourse searchCourseTitle = new CollegeCourse("", 0, searchTitle);
        
        //do a binary search and store the index it returns
        int searchIndex = Collections.binarySearch(catalog, searchCourseTitle, new ComparatorByCourseTitle());
        //if the index is not -1, display the entire object at that index
        if (searchIndex >= 0)
        {
            //add the index returned from the binary search into the index arraylist
            indexes.add(searchIndex);
            
            //while the search title is still the same going backwards
            while(catalog.get(searchIndex).getCourseTitle().equalsIgnoreCase(searchTitle))
            {
                //add each index to the arraylist as long as the index is unique
                if(!indexes.contains(searchIndex))
                {
                    indexes.add(searchIndex);
                }
                //keep going backwards
                searchIndex--;
            }
            //start going forwards
            searchIndex++;
            //while the search title is still the same going backwards
            while(catalog.get(searchIndex).getCourseTitle().equalsIgnoreCase(searchTitle))
            {
                //add each index to the arraylist as long as the index is unique
                if(!indexes.contains(searchIndex))
                {
                    indexes.add(searchIndex);
                }
                //keep going forwards
                searchIndex++;
            }
            
            //display all the matching results
            System.out.println("Here is what came up for " + searchTitle + ": ");
            for(int i = 0; i < indexes.size(); i++)
            {
                System.out.println(catalog.get(indexes.get(i)));
            }
        }
        //else if the index is -1, display that the course was not found
        else
        {
            System.out.println("Sorry, your desired course was not found: " + searchTitle);
        }
    }
    
    //this method adds a course to an output file of courses using user info
    public void addCourse()
    {
        FileWriter fw;
        PrintWriter pw = null;
        String courseName, courseTitle;
        int courseCredits;
        CollegeCourse aCourse;
        boolean invalidData = true;
        boolean done = false;
      
      //keep looping while the data is invalid
      do
      {
        try
        {
            //ask for the credits of the course and store it
            System.out.print("\nHow many credits is the course? ");
            courseCredits = keyboard.nextInt();
            
            //if credits > 5 throw bad data exception
            if(courseCredits > 5)
            {
                throw new BadDataException();
            }
            //else dont loop again
            else
            {
                invalidData = false;
            }
            
            keyboard.nextLine();
            
            //ask for the name of the course and store it
            System.out.print("\nWhat is the name of the course? ");
            courseName = keyboard.nextLine();
            
            //ask for the title of the course and store it
            System.out.print("\nWhat is the title of the course? ");
            courseTitle = keyboard.nextLine();
            
            //store information into a course object
            aCourse = new CollegeCourse(courseName, courseCredits, courseTitle);
            
            //add the course the arraylist
            catalog.add(aCourse);
            
            //add the course to the output file
            fw = new FileWriter("SCISCourses2(1).txt", true);
            pw = new PrintWriter(fw);
            
            //concatenate it to have proper format
            pw.println(courseName + "\t" + courseCredits + "\t" + courseTitle);
            
            done = true;
        }
        //catches for various exceptions
        catch(FileNotFoundException e)
        {
            System.out.println("File Not Found!");
        }
        catch(BadDataException e)
        {
            invalidData = true;
            System.out.println("Credit hours cannot be greater than 5, Reenter a valid credit hour.");
        }
        catch(InputMismatchException e)
        {
            invalidData = true;
            System.out.println("Invalid Input! Credit hours must be a number!");
            keyboard.nextLine();
        }
        catch(Exception e)
        {
            System.out.println("Exception was caught!");
        }
        //finally to close output file
        finally
        {
            if(done)
            {
                pw.close();
            }
        }
      }while(invalidData);
    }
}
