/*
 * @author 5775423
 * 
 * Title: MidtermProject_5775423
 * Semester: COP38054 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads a file of courses. The user can sort the
 *                courses, search for a specific course, or add another course        
 */
package midtermproject;

import java.util.Comparator;

public class ComparatorByCourseTitle implements Comparator<CollegeCourse>
{
    //Compare to sort by course name
    @Override
    public int compare(CollegeCourse course1, CollegeCourse course2)
    {
        return course1.getCourseTitle().compareTo(course2.getCourseTitle());
    }
}
