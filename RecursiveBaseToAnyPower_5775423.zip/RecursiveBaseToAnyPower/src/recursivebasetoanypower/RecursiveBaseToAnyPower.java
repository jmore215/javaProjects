/*
 * @author 5775423
 * 
 * Title: RecursiveBaseToAnyPower_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program compares a recursive method and a loop method that
 *              caluclates the base to any power
 */
package recursivebasetoanypower;

import java.util.Scanner;

public class RecursiveBaseToAnyPower 
{
    public static void main(String[] args) 
    {
        //instantiate the driver
        RecursiveBaseToAnyPower myPower = new RecursiveBaseToAnyPower(); 
        
        int base, exp, answer;
        long start, end, result, start2, end2, result2;
        
        Scanner keyboard = new Scanner(System.in);
        
        //ask for the base and the power and store it
        System.out.print("What is the base? ");
        base = keyboard.nextInt();
        System.out.print("What is the power? ");
        exp = keyboard.nextInt();
        
        //calculate the start time of the recursive method
        start = System.nanoTime();
        //call the recursive method using user base and exponent
        answer = myPower.powRecursive(base, exp);
        //calculate the end time of the recursive method
        end = System.nanoTime();
        //get total time by subtracting start from end
        result = end - start;
        //print the answer and total time
        System.out.println("\nRecursive Answer is " + answer);
        System.out.println("Total time: " + result + " nanoseconds");
        
        //calculate the start time of the loop method
        start2 = System.nanoTime();
        //call the loop method using user base and exponent
        answer = myPower.powLoop(base, exp);
        //calculate the end time of the loop method
        end2 = System.nanoTime();
        //get total time by subtracting start from end
        result2 = end2 - start2;
        //print the answer and total time
        System.out.println("\nLoop Answer is " + answer);
        System.out.println("Total time: " + result2 + " nanoseconds");
        
        //if else to determine which method was the fastest
        if(result < result2)
        {
            System.out.println("\nThe fastest method is the recursive method.");
        }
        else
        {
            System.out.println("\nThe fastest method is the loop method.");
        }
    }
    
    //this method calculates the base to any power recursively
    public int powRecursive(int base, int exp)
    {
        //if the exponent is <= 0, stop looping and return 1
        if (exp <= 0)
            return 1;
        //else call itself and times the exponent by the base
        else
            return base * powRecursive(base,exp - 1);
    }
    
    //this method calculates the base to any power using a loop
    public int powLoop(int base, int exp)
    {
        int answer = 1;
        
        //for loop to start at 1 and increment till it reaches exponent number
        for(int i = 1; i <= exp; i++)
        {
            //multiple base times the answer each time it loops
            answer *= base;
        }
        //return the answer
        return answer;
    }
}
