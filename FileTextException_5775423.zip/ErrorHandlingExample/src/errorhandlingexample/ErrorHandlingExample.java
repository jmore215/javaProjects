/*
 * @author 5775423
 * 
 * Title: FileTextException_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program displays a menu of files and exception,
 *             and displays a summary of results.
 */
package errorhandlingexample;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class ErrorHandlingExample {

    //Define a global array of Student objects, but don't instantiate it until the getUserInput() method.
    public Student[] students;
    public Student[] studentsCopy;
    public File aFile;
    public Scanner myFile;
    public Scanner keyboard = new Scanner(System.in);
    public int numRecs = 0;
    public int actualNumRecs = 0;
    public boolean threwNoSuchElement = false;
    public DecimalFormat df  = new DecimalFormat("##0.00");
    
    public static void main(String[] args){
       boolean tryAgain = true;
       int menuItemSelected = 0;
       //instantiate the driver
       ErrorHandlingExample errorHandle1 = new ErrorHandlingExample();
       //while loop to retry any exceptions that were thrown
       while (tryAgain)
       {
           try
           {
               //display menu and store selection
               menuItemSelected = errorHandle1.getUserInput();
               //process file selection
               errorHandle1.processFile(menuItemSelected);
               //summarize results in file
               errorHandle1.summarizeResults();
               //dont try again
               tryAgain = false;
           }
           //try again
           catch (FileNotFoundException e)
           {
               tryAgain = true;
               System.out.println(e.getMessage());
           }
           //dont try again
           catch (InputMismatchException e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           //dont try again
           catch (BadDataException e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           //dont try again
           catch (NoSuchElementException e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           //dont try again
           catch (Exception e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
       }
    }
    
    //this method displays the menu and validates the user's input
    public int getUserInput() 
    {
        boolean validMenu = false;
        
        int usersChoice = 0;
       
        //while loop to validate user input
        while (!validMenu)
        {
            try
            {
                //call method to display menu and store option
                displayMenu();
                usersChoice = keyboard.nextInt();
                //if user input is outside range, display error message
                if (usersChoice < 1 || usersChoice > 6)
                {
                    System.out.println("Your selection is invalid. Enter  1 - 6.");
                    //loop again
                    validMenu = false;
                }
                //end loop
                else
                {
                    validMenu = true;
                }
                               
            }
            //if what the user enters is not a number, catch this exception
            catch(InputMismatchException e)
            {
                //loop again
                validMenu = false;
                keyboard.nextLine();
                //display error message
                System.out.println("Incorrect menu selection.");
            }
        }
        //return user input to main
        return usersChoice;
    }
    
    //this method processes the desired file selection
    public void processFile(int usersChoice) throws FileNotFoundException, Exception
    {
        String fileName;
        String badData1 = "goodFile.txt";
        String badData2 = "tooFewRecs.txt";
        String badData3 = "tooManyRecs.txt";
        String badData4 = "nonNumericRecCounter.txt";
        String badData5 = "invalidData.txt";
        String badData6 = "xyz.txt";
        
        //switch to set fileName to desired file choice 
        switch (usersChoice)
        {
            case 1:
                fileName = badData1;
                break;
            case 2:
                fileName = badData2;
                break;
            case 3:
                fileName = badData3;
                break;
            case 4:
                fileName = badData4;
                break;
            case 5:
                fileName = badData5;
                break;
            case 6:
                fileName = badData6;
                break;
            default:
                fileName = badData1;
        }
        
        //create variables for file reading 
        int count = 0;
        String badNumRecs = "";
        Student aStudent;
        String lastname = "";
        double gpa = 0.0; 
        
        //boolean for while loop
        boolean done = false;
        //boolean to figure out correct exception to throw
        boolean invalidRecCounter = true;
        
      //while loop that will continue looping till done is true
      while(!done)
      {
        try
        {
           //open file
           aFile = new File(fileName);
           //if file doesnt exist
           if(!aFile.exists())
           {
               //throw exception of file not found
               throw new FileNotFoundException();
           }
           //scanner for file reading
           myFile = new Scanner(aFile);
           
           //read first line containing number of records in current file
           numRecs = myFile.nextInt();
           
           //set to false for a different InputMismatchException that may occur
           invalidRecCounter = false;
            
           //This is where you instantiate the array of Student objects, and
           //where you use a counter loop, using numRecs as number of time to loop, 
           //to read all the records in the input file, and 
           //create a Student object per record, to place in the global array of Student objects
           //You can do these steps either right here, or by calling a method that does them.
           //When this method successfully ends, the array of Student objects should be populated.
           
           //set the array = to the number of records in file
           students = new Student[numRecs];
           
           //continue reading while counter is less than number of records
           while(count < numRecs)
           {
               //read last name and gpa for each line
               lastname = myFile.next();
               gpa = myFile.nextDouble();
               
               //store into a student object
               aStudent = new Student(lastname, gpa);
               //store into array at current index of count
               students[count] = aStudent;
               
               //increment count by 1
               count++;
           }
           
           //if the file still has data to be read...
           if(myFile.hasNext())
           {
               //throw a BadDataException
               throw new BadDataException();
           }
           
           //end loop once done
           done = true;
        }
        //occurs for option 6 using file name: "xyz.txt"
        catch (FileNotFoundException e)
        {
            //display that the file wasnt found and ask for a file name until
            // the file name given exists
            System.out.println("FILE NOT FOUND EXCEPTION WAS THROWN!!!");
            System.out.print("The file " + fileName + " was not found. Enter new file name: ");
            fileName = keyboard.next();
        }
        //occurs for options 4 and 5 for files:
        //   "nonNumericRecCounter.txt" & "invalidData.txt"
        catch (InputMismatchException e)
        {
            //occurs for option 4 for file: "nonNumericRecCounter.txt"
            if(invalidRecCounter == true)
            {
                //close the file
                myFile.close();
                
                //open file to start from beginning
                aFile = new File(fileName);
                myFile = new Scanner(aFile);
                
                //read each line as long as the following line isnt null
                while(myFile.hasNextLine())
                {
                    if(myFile.nextLine() != null)
                    {
                        //increment count
                        count++;
                    }
                }
                //close file
                myFile.close();
                
                //subtract 1 from count to exclude the first line since it isnt
                // a record, then store the actual number of records
                actualNumRecs = count - 1;
                //set count back to 0
                count = 0;
                //set the size of the array to the actual number of records
                students = new Student[actualNumRecs];
                
                //open file again to read the student information
                aFile = new File(fileName);
                myFile = new Scanner(aFile);
                
                //read the first line, ignore it, and continue reading
                badNumRecs = myFile.nextLine();
                
                //while loop for reading
                while(count < actualNumRecs)
                {
                    //read the lastname and gpa
                    lastname = myFile.next();
                    gpa = myFile.nextDouble();
                    //store it into a student object
                    aStudent = new Student(lastname, gpa);
                    //store the object into the array at current index of count
                    students[count] = aStudent;
                    //increment count
                    count++;
                }
                //call method to summarize results since it was fixed
                summarizeResults();
                //throw input mismatch exception message had occured but was fixed
                throw new InputMismatchException("\nINVALID RECORD COUNTER!(INPUT MISMATCH EXCEPTION) NOW FIXED");
            }
            //occurs for option 5 for file: "invalidData.txt"
            else
            {
                //throw input mismatch exception message had occured when
                //   reading the GPA in the file
                throw new InputMismatchException("Expecting numeric GPA, got non-numeric GPA.(INPUT MISMATCH EXCEPTION)");
            }
        }
        //occurs for option 3 using file name: "tooManyRecs.txt"
        catch (BadDataException e)
        {
             //You can report on the bad data, and skip the bad record, so you can process the rest of the records.
            
            //close the file
            myFile.close();
            
            //open file again to start from the beginning
            aFile = new File(fileName);
            myFile = new Scanner(aFile);
            
            //set the count = 0 to prepare for correct amount of records 
            count = 0;
            
            //read each line
            while(myFile.hasNextLine())
            {
                //if the line is not null...
                if(myFile.nextLine() != null)
                {
                    //increment count of records by 1
                    count++;
                }
            }
            //close file
            myFile.close();
            
            //subtract 1 from count to exclude the first line since it isnt
            // a record, then store the actual number of records
            actualNumRecs = count - 1;
            //reset counter
            count = 0;
            //set the size of the array to the actual amount of records
            students = new Student[actualNumRecs];
            
            //open file again to actually read records
            aFile = new File(fileName);
            myFile = new Scanner(aFile);
            
            //read first line of file, ignore, and continue
            badNumRecs = myFile.nextLine();
            
            //while loop to read records
            while(count < actualNumRecs)
            {
                //read each last name and gpa
                lastname = myFile.next();
                gpa = myFile.nextDouble();
                
                //store into a new student object
                aStudent = new Student(lastname, gpa);
                //store the student object at current index of count
                students[count] = aStudent;
                //increment count
                count++;
            }
            //call sumarrize results method since problem was fixed
            summarizeResults();
           //throw the bad data exception but notify that it was fixed
           throw new BadDataException("\nMore recs than anticipated!(BadDataException Thrown) FIXED NOW.");
        }
        //occurs for option 2 for file: "tooFewRecs.txt"
        catch (NoSuchElementException e)
        {
            //if the file doesnt have anymore elements to store into array...
            if(!myFile.hasNext())
            {
                //create a copy of the array by subtracting the length of the
                //  original by what was counted
                studentsCopy = Arrays.copyOf(students, students.length - count);
            }
            //boolean to show the results for the copy of student array
            threwNoSuchElement = true;
            //call method to summarize results for fixed copy of array
            summarizeResults();
            //throw message of NoSuchElementException but notify that it was fixed
            throw new NoSuchElementException("\nNO SUCH ELEMENT EXCEPTION WAS THROWN AND FIXED...\n");
        }
        //occurs for any other exception that may be thrown
        catch (Exception e)
        {
            //throw exception back to main
            throw new Exception();
        }
        //Finally close file if it exists...
        finally
        {
            if(aFile.exists())
            {
                myFile.close();
            }
        }
      }
    }           
    
    //this method contains the menu to be displayed and is called when
    // validating user input
    public void displayMenu()
    {
        System.out.println("What type of file do you wish to read?");
        System.out.println("1.  Good File");
        System.out.println("2.  Too few recs in the counter (more recs than anticipated");
        System.out.println("3.  Too many recs in the counter (less recs than anticipated");
        System.out.println("4.  Non-numeric record counter");
        System.out.println("5.  Invalid data in record - ex. GPA non-numeric");
        System.out.println("6.  Invalid file name");
    }
    
    //this method summarizes the results when calculating info in the student array
    public void summarizeResults()
    {
        //This is where you use the array of Student objects you created, and you
        //loop through it, finding the student with the highest gpa, the lowest gpa, and then
        //accumulate all the gpas, so that at the end of the loop, you can calculate the average gpa.
        
        //You can optionally put try catch for the arrayOutOfBounds error.
       //By now, the data in the array should be valid, since any errors were caught in the processFile method
       //You should have skipped the bad data recs.
        
        //If you skipped a bad data record, you could have an array with empty elements.  Thus, 
        //you could have exceptions if you don't first check that the element is not equal to nulls.
        
        //set most of these variables according to the first item in the array
        double lowestGPA = students[0].getGpa();
        String lowestLast = students[0].getLastName();
        double highestGPA = students[0].getGpa();
        String highestLast = students[0].getLastName();
        double sum = students[0].getGpa();
        double average;
        
        //if statement to summarize the results for the fixed copy of student 
        // array instead of original
        if(threwNoSuchElement == true)
        {
            //set the variables to the info in the first item of the copy instead
            lowestGPA = studentsCopy[0].getGpa();
            lowestLast = studentsCopy[0].getLastName();
            highestGPA = studentsCopy[0].getGpa();
            highestLast = studentsCopy[0].getLastName();
            sum = studentsCopy[0].getGpa();
            
            //for loop that starts at the next item in array
            for(int i = 1; i < studentsCopy.length; i++)
            {
                //use the item at the index as long as the info isnt null
                if(studentsCopy[i] != null)
                {
                    //add all of the gpa's together
                    sum += studentsCopy[i].getGpa();
                    
                    //to get the lowest gpa
                    if(studentsCopy[i].getGpa() < lowestGPA)
                    {
                        //store current lowest
                        lowestGPA = studentsCopy[i].getGpa();
                        lowestLast = studentsCopy[i].getLastName();
                    }
                    //to get the highest gpa
                    if(studentsCopy[i].getGpa() > highestGPA)
                    {
                        //store current highest
                        highestGPA = studentsCopy[i].getGpa();
                        highestLast = studentsCopy[i].getLastName();
                    }
                }
            }
            //calculate average using the sum / by length of copy array
            average = sum / studentsCopy.length;
            //display results
            System.out.println("The student with the lowest gpa is: " 
                + lowestLast + " with gpa of: " + lowestGPA);
            System.out.println("The student with the highest gpa is: " 
                    + highestLast + " with gpa of: " + highestGPA);
            System.out.println("The average of all students' gpa is: " 
                    + df.format(average));
        }
        //use original array
        else
        {
            //for loop starts at the next item in array
            for(int i = 1; i < students.length; i++)
            {
                //use the item at the index as long as the info isnt null
                if(students[i] != null)
                {
                    //add all of the gpa's together
                    sum += students[i].getGpa();
                    //to get the lowest gpa
                    if(students[i].getGpa() < lowestGPA)
                    {
                        //store current lowest
                        lowestGPA = students[i].getGpa();
                        lowestLast = students[i].getLastName();
                    }
                    //to get the highest gpa
                    if(students[i].getGpa() > highestGPA)
                    {
                        //store current highest
                        highestGPA = students[i].getGpa();
                        highestLast = students[i].getLastName();
                    }
                }
            }
            //calculate average using the sum / by length of the array
            average = sum / students.length;
            //display results
            System.out.println("The student with the lowest gpa is: " 
                    + lowestLast + " with gpa of: " + lowestGPA);
            System.out.println("The student with the highest gpa is: " 
                    + highestLast + " with gpa of: " + highestGPA);
            System.out.println("The average of all students' gpa is: " 
                    + df.format(average));
        }
    }
}