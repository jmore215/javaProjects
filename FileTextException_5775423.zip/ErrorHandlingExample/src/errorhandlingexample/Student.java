/*
 * @author 5775423
 * 
 * Title: FileTextException_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program displays a menu of files and exception,
 *             and displays a summary of results.
 */
package errorhandlingexample;

public class Student {
    
    //instance variables
    private String lastName;
    private double gpa;
    
    //constructor
    public Student(String ln, double aGPA)
    {
        lastName = ln;
        gpa = aGPA;
    }
    
    //getters
    public String getLastName() {
        return lastName;
    }

    public double getGpa() {
        return gpa;
    }
    
    //setters
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
  
    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    
    @Override
    public String toString() {
        return "Student{" + "lastName=" + lastName + ", gpa=" + gpa + '}';
    }
}
