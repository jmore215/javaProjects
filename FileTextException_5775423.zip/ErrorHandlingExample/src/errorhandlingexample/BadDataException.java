/*
 * @author 5775423
 * 
 * Title: FileTextException_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program displays a menu of files and exception,
 *             and displays a summary of results.
 */
package errorhandlingexample;

//bad data exception extends runtime exception
public class BadDataException extends RuntimeException 
{
    //default constructor using constructor of super
    public BadDataException()
    {
        super();
    }
    
    //non-default constructor for message
    public BadDataException(String message)
    {
        super(message);
    }
}
