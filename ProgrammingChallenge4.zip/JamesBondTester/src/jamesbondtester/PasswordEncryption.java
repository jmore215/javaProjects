/*
 * @author 5775423
 *
 * Title: ProgrammingChallenge4
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program encrypts and decrypts words.
 */
package jamesbondtester;


public class PasswordEncryption 
{
    //global variables for original word and encrypted word
    String origWord;
    String encryptWord;
    
    //constructor
    public PasswordEncryption(String word, boolean encrypt) 
    {
        //if encrypt is true
        if (encrypt)
        {
            this.origWord = word;
            this.encryptWord = "";
        }
        //else encrypt is false
        else
        {
           this.encryptWord = word;
           this.origWord = "";
        }
    }
    
    //getter
    public String getOrigWord() 
    {
        return origWord;
    }
    
    //setter
    public void setOrigWord(String origWord) 
    {
        this.origWord = origWord;
    }
    
    //getter
    public String getEncryptedWord() 
    {
        return encryptWord;
    }
    
    //setter
    public void setEncryptedWord(String encryptWord) 
    {
        this.encryptWord = encryptWord;
    }
    
    public String toString()
    {
        return "Original Word: " + origWord + "\nEncrypted Word: " + encryptWord;
    }
    
    //encrypts whatever word is given
    public void encryptOrig()
    {
        //Add code to take the origWord and encrypt it, storing 
        //the encrypted word in encryptWord
        
        //create variables
        char letter, newLetter;
        int newLetterNum;
        
        //for loop for each letter in word, 0 < length of origWord
        for(int i = 0; i<origWord.length(); i++)
        {
            //(use charAt(i)) to store in char variable
            letter = origWord.charAt(i);
            //if statement here for x,y,z, to start back at a
            if(letter == 'x')
            {
                //letter becomes a
                newLetter = 'a';
            }
            else if(letter == 'y')
            {
                //letter becomes b
                newLetter = 'b';
            }
            else if(letter == 'z')
            {
                //letter becomes c
                newLetter = 'c';
            }
            else
            {
                //cast char to an int and add 3
                newLetterNum = ((int)letter) + 3;
            
                //cast int back to a char
                newLetter = (char)newLetterNum;
            }
           
            //variable += new letter
            encryptWord += newLetter;
        } 
        
    }
    
    //decrypts whatever word is given
    public void decryptEncrypt()
    {
        //Add code to take the encryptWord and decrypt it, storing
        //the original word in origWord
        
        //create variables
        char letter, origLetter;
        int origLetterNum;
        
        //for loop for each letter in word, 0 < length of encryptWord
        for(int i = 0; i<encryptWord.length(); i++)
        {
            //(use charAt(i)) to store in char variable
            letter = encryptWord.charAt(i);
            //if statement here for a,b,c to start back at x
            if(letter == 'a')
            {
                //letter becomes x
                origLetter = 'x';
            }
            else if(letter == 'b')
            {
                //letter becomes y
                origLetter = 'y';
            }
            else if(letter == 'c')
            {
                //letter becomes z
                origLetter = 'z';
            }
            else
            {
                //cast char to an int and subtract 3
                origLetterNum = ((int)letter) - 3;
            
                //cast int back to a char
                origLetter = (char)origLetterNum;
            }
           
            //variable += original letter
            origWord += origLetter;
        } 
    }
}
