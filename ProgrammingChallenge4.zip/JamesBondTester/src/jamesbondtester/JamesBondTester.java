/*
 * @author 5775423
 *
 * Title: ProgrammingChallenge4
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program encrypts and decrypts words.
 */
package jamesbondtester;

//import scanner
import java.util.Scanner;

public class JamesBondTester 
{

    public static void main(String[] args) 
    {
        int menuOption;
        
        //Add a do-while loop that keeps looping while the user 
        //enters either 1 or 2.
        do
        {
            menuOption = displayMenu();
            
            switch(menuOption)
            {
                case 1:
                    encryptPassword();
                    break;
                case 2:
                    decryptPassword();
                    break;
                case 3:
                    selfDestruct();
                    break;
            }
        }while(menuOption == 1 || menuOption == 2);
    }
    
    //this method displays a menu and validates user's input
    public static int displayMenu()
    {
        //variable for user input
        int option;
        
        //Create a scanner object
        Scanner keyboard = new Scanner(System.in);
        
        //Display the menu to show:
        // 1.  Encrypt a Password?
        // 2.  Decrypt a Password?
        // 3.  Stop Spying...
        
        //Get input from user and store in a local variable
        //loop to validate value entered as 1, 2, or 3
        //and if not, keep looping and asking user to enter valid value
        do
        {
            System.out.println("1. Encrypt a Password?\n2. Decrypt a Password?\n3. Stop Spying...\n");
            //Get input from user and store in a local variable
            option = keyboard.nextInt();
            //loop to validate value entered as 1, 2, or 3
            //and if not, keep looping and asking user to enter valid value
            if(option < 1 || option > 3)
            {
                System.out.println("\nEnter a valid value!\n");
                System.out.println("1. Encrypt a Password?\n2. Decrypt a Password?\n3. Stop Spying...\n");
                option = keyboard.nextInt();
            }
        }while(option < 1 || option > 3);
        //return value entered
        return option;   
    }
    //this method encrypts a word
    public static void encryptPassword()
    {
        //variables for user input and to compare guess with the correct encrypted word
        String word,guess; 
        
        //create a scanner object
        Scanner keyboard = new Scanner(System.in);
        
        //1.  Ask user for word to encrypt
        System.out.println("Enter a word to encrypt.");
        word = keyboard.nextLine();
        
        //2.  Instantiate the PasswordEncryption object, passing
        //    it the word and a boolean value of true, meaning encrypt
        PasswordEncryption encrypt = new PasswordEncryption(word, true);
        encrypt.encryptOrig();
        //4.  Extra Credit: Before displaying encrypted word,
        //    ask user to guess the encrypted word.  If user guesses
        //    correctly, state "Successfully encrypted…mission accomplished"
        //    If user did not guess correctly, state "Unsuccessfully encrypted...Danger, danger!”
        
        //ask user to guess what the encrypted word is
        System.out.println("Guess what the encrypted word is...");
        guess = keyboard.nextLine();
        
        if(encrypt.getEncryptedWord().equalsIgnoreCase(guess))
        {
            System.out.println("Successfully encrypted…mission accomplished!");
        }
        else
        {
            System.out.println("Unsuccessfully encrypted...Danger, danger!");
        }
        
        //3.  Display the encrypted word to the user.
        System.out.println(encrypt);
        
    }
    //this method decrypts a word
    public static void decryptPassword()
    {   //1.  Ask user for encrypted word to decrypt
        
        //variables for user input and to compare guess with the correct encrypted word
        String word,guess;
        
        //create scanner object
        Scanner keyboard = new Scanner(System.in);
        
        //ask user what word they want decrypted
        System.out.println("Enter a word to decrypt.");
        word = keyboard.nextLine();
        
        //2.  Instantiate the PasswordEncryption object, passing
        //    it the word and a boolean value of false, meaning decrypt
        PasswordEncryption decrypt = new PasswordEncryption(word, false);
        decrypt.decryptEncrypt();
        
        //4.  Extra Credit: Before displaying decrypted word,
        //    ask user to guess the decrypted word.  If user guesses
        //    correctly, state "Successfully decrypted…mission accomplished"
        //    If user did not guess correctly, state "Unsuccessfully decrypted...Danger, danger!”
        System.out.println("Guess what the decrypted word is...");
        guess = keyboard.nextLine();
        
        if(decrypt.getOrigWord().equalsIgnoreCase(guess))
        {
            System.out.println("Successfully encrypted…mission accomplished!");
        }
        else
        {
            System.out.println("Unsuccessfully decrypted...Danger, danger!");
        }
        //3.  Display the decrypted word to the user.
        System.out.println(decrypt);
        
    }
    //this method self destructs and stops the program
    public static void selfDestruct()
    {
        //Advise the user that this program will self-destruct in 5 seconds
        //5 - 4 - 3 - 2 - 1 - 0 Boom!
        System.out.println("5 - 4 - 3 - 2 - 1 - 0 BOOM!");
    }
    
}
