/*
 * @author 5775423
 * 
 * Title: Programming Challenge 5
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program has 2 cars race each other and saves the winner
 *              of the race to a file.
 */

package drivingsimulation;

//import scanner and file io
import java.util.Scanner;
import java.io.*;

public class DrivingSimulation 
{
    //global variables for car objects, each car's personal best, and final lap speed
    public static Car car1;
    public static Car car2;
    public static int fastestSpeedCar1 = 0;
    public static int fastestSpeedCar2 = 0;
    public static int lastSpeedCar1 = 0;
    public static int lastSpeedCar2 = 0;
    
    public static void main(String[] args) throws IOException
    {
        //call method to create both cars
        setUpCars();
        //call method to make the cars race
        raceCarsLoop();
        //call method to display results
        showSaveResults();
    }
    
    //this method creates 2 cars
    public static void setUpCars()throws IOException
    {
        //create local variables for car attributes
        String make = "";
        String model = "";
        int year = 0;
        int speed = 0;
        
        //create variable for user file input
        String winner = "";
        
        //create car 1
        car1 = new Car();
        
        //create a scanner object for user input
        Scanner keyboard = new Scanner(System.in);
        
        //ask user for name of the file that contains the previous winner
        System.out.println("Enter the name of the file that contains the data of the previous winning car.");
        winner = keyboard.nextLine();
        
        //read and scan the file
        File userFile = new File(winner);
        Scanner inFile2 = new Scanner(userFile);
        
        while(inFile2.hasNext())
        {
            make = inFile2.next();
            model = inFile2.next();
            year = inFile2.nextInt();
            speed = inFile2.nextInt();
        }
        
        //use setters to change car attributes according to the previous winner
        car1.setMake(make);
        car1.setModel(model);
        car1.setYear(year);
        car1.setSpeed(speed);
        
        //close the file
        inFile2.close();
                
        //create car 2
        //ask user to create a car object
        System.out.println("What is the make of Car #2?");
        make = keyboard.nextLine();
        System.out.println("What is the model of Car #2?");
        model = keyboard.nextLine();
        System.out.println("What is the year of Car #2?");
        year = keyboard.nextInt();
        System.out.println("What is the initial speed of Car #2?");
        speed = keyboard.nextInt();
        
        //pass the input into car object
        car2 = new Car(make, model, year, speed);
        
        //Display info in each car
        System.out.println("\n*** Car 1 ***\n" + car1 + "\n\n*** Car 2 ***\n" + car2 + "\n\n");
        
        //reset starting speed of each car to zero
        car1.setSpeed(0);
        car2.setSpeed(0);
    }
    
    //this method uses a for loop to have the cars race for five laps
    public static void raceCarsLoop()
    {
        //display a message stating that the cars are about to race
        System.out.println("A race is starting between the " + car1.getYear() 
                + " " + car1.getMake() + " " + car1.getModel() + " and the "
                + car2.getYear() + " " + car2.getMake() + " " + car2.getModel() + "!!!\n");
        
        //for loop to race around track 5 times
        for(int i = 1; i<=5; i++)
        {
            //display which lap the race is currently on
            System.out.println("***** LAP " + i + " *****");
            
            //call method to make both cars accelerate
            System.out.println("Accelerating!");
            car1.accelerate();
            car2.accelerate();
            
            //display the current speed
            System.out.println("Speed of " + car1.getYear() + " " + car1.getMake() + " " + car1.getModel() + ": " + car1.getSpeed() + " mph");
            System.out.println("Speed of " + car2.getYear() + " " + car2.getMake() + " " + car2.getModel() + ": " + car2.getSpeed() + " mph");
            
            //get the personal best speed for each car using two separate if statements 
            if(car1.getSpeed() > fastestSpeedCar1)
            {
                fastestSpeedCar1 = car1.getSpeed();
            }
            if(car2.getSpeed() > fastestSpeedCar2)
            {
                fastestSpeedCar2 = car2.getSpeed();
            }
            
            //call method to make both cars brake
            System.out.println("Braking!");
            car1.brake();
            car2.brake();
            
            //display current speed of each car again
            System.out.println("Current Speed of " + car1.getYear() + " " + car1.getMake() + " " + car1.getModel() + ": " + car1.getSpeed() + " mph");
            System.out.println("Current Speed of " + car2.getYear() + " " + car2.getMake() + " " + car2.getModel() + ": " + car2.getSpeed() + " mph\n");
            
            
            //for last lap save each car's final speed to determine winner later
            if(i == 5)
            {
                lastSpeedCar1 = car1.getSpeed();
                lastSpeedCar2 = car2.getSpeed();
            }
        }    
    }
    
    //this method displays overall results
    public static void showSaveResults() throws IOException
    {
        //display each car's personal best
        System.out.println("Fastest speed " + car1.getYear() + " " + car1.getMake() + " " + car1.getModel() + " reached: " + fastestSpeedCar1);
        System.out.println("Fastest speed " + car2.getYear() + " " + car2.getMake() + " " + car2.getModel() + " reached: " + fastestSpeedCar2);
        
        //if car 1 was faster than car 2 in the last lap
        if(lastSpeedCar1 > lastSpeedCar2)
        {
            //display car 1 is the winner
            System.out.println("\nWinner of last lap was...\n" + car1);
            
            //save winner of race in file
            PrintWriter pw = new PrintWriter("race.txt");
            
            //save in the order of make, model, year, and speed with a space in between as delimiter
            pw.println(car1.getMake() + " " + car1.getModel() + " " + car1.getYear() + " " + car1.getSpeed());
            
            //close file
            pw.close();
        }
        //else if car 2 was faster than car 1 in the last lap
        else if(lastSpeedCar1 < lastSpeedCar2)
        {
            //display car 2 is the winner
            System.out.println("\nWinner of last lap was...\n" + car2);
            
            //save winner of race in file
            PrintWriter pw = new PrintWriter("race.txt");
            
            //save in the order of make, model, year, and speed with a space in between as delimiter
            pw.println(car2.getMake() + " " + car2.getModel() + " " + car2.getYear() + " " + car2.getSpeed());
            
            //close file
            pw.close();
        }
        
        
    }
}
