/*
 * @author 5775423
 * 
 * Title: Programming Challenge 5
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program has 2 cars race each other and saves the winner
 *              of the race to a file.
 */

package drivingsimulation;

//import random
import java.util.Random;

public class Car 
{
    //instance variables
    private int year;
    private String model;
    private String make;
    private int speed;
    
    //default car constructor
    public Car()
    {
        make = "Kia";
        model = "Spectra";
        year = 2018;
        speed = 100;
    }
    
    //car constuctor with arguments in parameters, initializing instance variables
    public Car(String aMake, String aModel, int aYear, int aSpeed)
    {
        make = aMake;
        model = aModel;
        year = aYear;
        speed = aSpeed;
    }
    
    //getters
    public String getMake()
    {
        return make;
    }
    public String getModel()
    {
        return model;
    }
    public int getYear()
    {
        return year;
    }
    public int getSpeed()
    {
        return speed;
    }
    
    //setters
    public void setMake(String anyMake)
    {
        make = anyMake;
    }
    public void setModel(String anyModel)
    {
        model = anyModel;
    }
    public void setYear(int anyYear)
    {
        year = anyYear;
    }
    public void setSpeed(int anySpeed)
    {
        speed = anySpeed;
    }
    
    //this method accelerates the car by adding a random number 
    //between 5 and 70 to speed
    public void accelerate()
    {
        //local variable to store random number
        int ranNum;
        
        //create a random object
        Random myRan = new Random();
        
        //generate random number from 5 to 70
        ranNum = myRan.nextInt(66)+5;
        
        //add random number to speed
        speed += ranNum;
    }
    
    //this method deccelerates the car by subtracting a random number 
    //between 5 and 30 from speed
    public void brake()
    {
        //local variable to store random number
        int ranNum;
        
        //create a random object
        Random myRan = new Random();
        
        //generate random number from 5 to 30
        ranNum = myRan.nextInt(26)+5;
        
        //subtract random number from speed
        speed -= ranNum;
    }
    
    //use toString to return the values in the car
    public String toString()
    {
        return "Make: " + make + "\n" + "Model: " + model + "\n" + "Year: " + year + "\n" + "Speed: " + speed;
    }
}
