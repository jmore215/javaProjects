/*
 * @author 5775423
 * 
 * Title: Programming Challenge 3
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program creates a Bingo game for the user to play. 
 */
package bingo;

//import scanner
import java.util.Scanner;
//import random
import java.util.Random;

public class Bingo 
{
    //create a gameCard object
    public static BingoCard gameCard;
    //create a variable to count how many games the user won at bingo
    public static int totalGamesWon = 0;
    
    public static void main(String[] args) 
    {
       
        //Use do-while loop to do the following:
        //1.  instantiate a gameCard
        //2.  call the method playGame()
        //3.  call the method determineWinner()
        //4.  Ask user if they wish to play again? (1 = yes; 2 = no)
        //5.  Loop while user replies 1 
        
        //create a variable to store user input on whether they want to continue or not
        String userContinue = "1";
        
        //create a scanner object
        Scanner keyboard = new Scanner(System.in);
        
        //do while loop that will run as long as the user wants to keep playing 
        do
        {
            //create a new bingo card
            gameCard = new BingoCard();
            //call the method that plays the game 
            playGame();
            //call the method that determines if they are the winner
            determineWinner();
            //Display value in totalGamesWon
            System.out.println("You have won " + totalGamesWon + " game(s).");
            //ask if they want to play again
            System.out.println("Do you wish to play again? (1 = yes, 2 = no)");
            //store input and compare with the do-while condition
            userContinue = keyboard.nextLine();
            
            //use switch to either start another game, say goodbye, or say that they entered the wrong number 
            switch(userContinue)
            {
                case "1":
                    //display that another game will start
                    System.out.println("Starting another game!...");
                    //create another bingo card
                    gameCard = new BingoCard();
                    //call playGame method again
                    playGame();
                    //call determine winner method again
                    determineWinner();
                    //Display value in totalGamesWon
                    System.out.println("You have won " + totalGamesWon + " game(s).");
                    //ask if they want to play again
                    System.out.println("Do you wish to play again? (1 = yes, 2 = no)");
                    userContinue = keyboard.nextLine();
                    break;
                case "2":
                    //display goodbye
                    System.out.println("Goodbye");
                    break;           
                default:
                    //display that the input is invalid
                    System.out.println("Invalid Input! Enter 1 = Yes or 2 = No\n");
                    //ask if they want to play again
                    System.out.println("Do you wish to play again? (1 = yes, 2 = no)");
                    userContinue = keyboard.nextLine();
                    
            }     
        }while(userContinue.equalsIgnoreCase("1"));
        
        //display goodbye
        System.out.println("Please play again soon!");
    }
    
    //this method draws 25 numbers and checks if there is a match with the numbers on the bingo card
    public static void playGame()
    {
        int randomNum;
        //Loop 25 times, simulating the 25 balls in a BINGO game
        for(int i = 1; i <= 25; i++)
        {
            //Inside loop:
            //1.  Generate a random number between 1 and 75
            
            //create a random object
            Random myRandom = new Random();
            //set range of the random 25 numbers from 1 to 75, inclusive
            randomNum = myRandom.nextInt(75)+1;
            
            //2.  if the number generated is between 1–15, 
            //    check bNum1, bNum2, bNum3, bNum4, and bNum5 to see if there is a match;    
            //    if so, move a 0 to the matching instance variable in the gameCard
            if(randomNum>=1 && randomNum<=15)
            {
                if(gameCard.getbNum1() == randomNum)
                {
                    gameCard.setbNum1(0);
                }
                else if(gameCard.getbNum2() == randomNum)
                {
                    gameCard.setbNum2(0);
                }
                else if(gameCard.getbNum3() == randomNum)
                {
                    gameCard.setbNum3(0);
                }
                else if(gameCard.getbNum4() == randomNum)
                {
                    gameCard.setbNum4(0);
                }
                else if(gameCard.getbNum5() == randomNum)
                {
                    gameCard.setbNum5(0);
                }
            }
            //3.  if the number generated is between 16–30, 
            //    check iNum1, iNum2, iNum3, iNum4, and iNum5 to see if there is a match;    
            //    if so, move a 0 to the matching instance variable in the gameCard
            else if(randomNum>=16 && randomNum<=30)
            {
                if(gameCard.getiNum1() == randomNum)
                {
                    gameCard.setiNum1(0);
                }
                else if(gameCard.getiNum2() == randomNum)
                {
                    gameCard.setiNum2(0);
                }
                else if(gameCard.getiNum3() == randomNum)
                {
                    gameCard.setiNum3(0);
                }
                else if(gameCard.getiNum4() == randomNum)
                {
                    gameCard.setiNum4(0);
                }
                else if(gameCard.getiNum5() == randomNum)
                {
                    gameCard.setiNum5(0);
                }
            }
            //4.  if the number generated is between 31–45, 
            //    check nNum1, nNum2, nNum3, nNum4, and nNum5 to see if there is a match;    
            //    if so, move a 0 to the matching instance variable in the gameCard
            
            else if(randomNum>=31 && randomNum<=45)
           {
                if(gameCard.getnNum1() == randomNum)
                {
                    gameCard.setnNum1(0);
                }
                else if(gameCard.getnNum2() == randomNum)
                {
                    gameCard.setnNum2(0);
                }
                else if(gameCard.getnNum3() == randomNum)
                {
                    gameCard.setnNum3(0);
                }
                else if(gameCard.getnNum4() == randomNum)
                {
                    gameCard.setnNum4(0);
                }
                else if(gameCard.getnNum5() == randomNum)
                {
                    gameCard.setnNum5(0);
                }
           }
            //5.  if the number generated is between 46–60, 
            //    check gNum1, gNum2, gNum3, gNum4, and gNum5 to see if there is a match;    
            //    if so, move a 0 to the matching instance variable in the gameCard
           else if(randomNum>=46 && randomNum<=60)
           {
                if(gameCard.getgNum1() == randomNum)
                {
                    gameCard.setgNum1(0);
                }
                else if(gameCard.getgNum2() == randomNum)
                {
                    gameCard.setgNum2(0);
                }
                else if(gameCard.getgNum3() == randomNum)
                {
                    gameCard.setgNum3(0);
                }
                else if(gameCard.getgNum4() == randomNum)
                {
                    gameCard.setgNum4(0);
                }
                else if(gameCard.getgNum5() == randomNum)
                {
                    gameCard.setgNum5(0);
                }
           }
            //6.  if the number generated is between 61–75, 
            //    check oNum1, oNum2, oNum3, oNum4, and oNum5 to see if there is a match;    
            //    if so, move a 0 to the matching instance variable in the gameCard
           else if(randomNum>=61 && randomNum<=75)
           {
                if(gameCard.getoNum1() == randomNum)
                {
                    gameCard.setoNum1(0);
                }
                else if(gameCard.getoNum2() == randomNum)
                {
                    gameCard.setoNum2(0);
                }
                else if(gameCard.getoNum3() == randomNum)
                {
                    gameCard.setoNum3(0);
                }
                else if(gameCard.getoNum4() == randomNum)
                {
                    gameCard.setoNum4(0);
                }
                else if(gameCard.getoNum5() == randomNum)
                {
                    gameCard.setoNum5(0);
                }
           }
        }
    }
    //this method displays the gamecard object, checks if there was vertical, horizontal, or diagonal bingo, and keeps track of the number of games won
    public static void determineWinner()
    {
        Boolean wonBingo = false;
        //1.  Print the content of the Bingo Card, ensuring the display is formatted as follows:
        //    bNum1  iNum1  nNum1  gNum1  oNum1 
        //    bNum2  iNum2  nNum2  gNum2  oNum2 
        //    bNum3  iNum3  nNum3  gNum3  oNum3 
        //    bNum4  iNum4  nNum4  gNum4  oNum4 
        //    bNum5  iNum5  nNum5  gNum5  oNum5
        
        //display the values in the toString
        System.out.println(gameCard);
        
        //2.  Call the gotBingo() method for the gameCard
        wonBingo = gameCard.gotBingo();
        
        //3.  if gotBingo() returns true, add 1 to totalGamesWon
        //    AND display "BINGO!"
        if(wonBingo == true)
        {
            totalGamesWon++;
            System.out.println("BINGO!");
        }
        //4.  if gotBingo() returns false, display "No BINGO"
        else if(wonBingo == false)
        {
            System.out.println("No BINGO");
        }
        
    }   
}
