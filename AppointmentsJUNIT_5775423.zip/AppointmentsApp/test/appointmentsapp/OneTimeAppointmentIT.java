/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appointmentsapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Cristy
 */
public class OneTimeAppointmentIT {
    
    public OneTimeAppointmentIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
//        System.out.println("main");
//        String[] args = null;
       
        OneTimeAppointment onetime = new OneTimeAppointment("Birthday Celebration", "Jane Smith", 2018, 10, 19, 12, 30); 
        
        //test getters...
        //getDescription
        String expectedResult = "Birthday Celebration";
        String result = onetime.getDescription();
        assertEquals(expectedResult, result);
        
        //getName
        expectedResult = "Jane Smith";
        result = onetime.getName();
        assertEquals(expectedResult, result);
        
        //getYear
        int expectResult = 2018;
        int resultNum = onetime.getYear();
        assertEquals(expectResult, resultNum);
        
        //getMonth
        expectResult = 10;
        resultNum = onetime.getMonth();
        assertEquals(expectResult, resultNum);
        
        //getDay
        expectResult = 19;
        resultNum = onetime.getDay();
        assertEquals(expectResult, resultNum);
        
        //getHour
        expectResult = 12;
        resultNum = onetime.getHour();
        assertEquals(expectResult, resultNum);
        
        //getMinute
        expectResult = 30;
        resultNum = onetime.getMinute();
        assertEquals(expectResult, resultNum);
        
        //test toString()...
        expectedResult = "OneTimeAppointment{" + "description=" + onetime.getDescription() + ", name=" 
                + onetime.getName() + ", year=" + onetime.getYear() + ", month=" + onetime.getMonth() 
                + ", day=" + onetime.getDay() + ", hour=" + onetime.getHour() + ", minute=" 
                + onetime.getMinute() + '}';
        result = onetime.toString();
        assertEquals(expectedResult, result);
    }
    
}
