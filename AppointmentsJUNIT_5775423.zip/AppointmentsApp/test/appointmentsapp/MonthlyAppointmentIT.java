/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appointmentsapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Cristy
 */
public class MonthlyAppointmentIT {
    
    public MonthlyAppointmentIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
//        System.out.println("main");
//        String[] args = null;
       
        MonthlyAppointment monthly = new MonthlyAppointment("manicure", "Kim", 15, 11, 45); 
        
        //test getters...
        //getDescription
        String expectedResult = "manicure";
        String result = monthly.getDescription();
        assertEquals(expectedResult, result);
        
        //getName
        expectedResult = "Kim";
        result = monthly.getName();
        assertEquals(expectedResult, result);
        
        //getDay
        int expectResult = 15;
        int resultNum = monthly.getDay();
        assertEquals(expectResult, resultNum);
        
        //getHour
        expectResult = 11;
        resultNum = monthly.getHour();
        assertEquals(expectResult, resultNum);
        
        //getMinute
        expectResult = 45;
        resultNum = monthly.getMinute();
        assertEquals(expectResult, resultNum);
        
        //test toString()...
        expectedResult = "MonthlyAppointment{" + "description=" + monthly.getDescription() + ", name=" 
                + monthly.getName() + ", day=" + monthly.getDay() + ", hour=" + monthly.getHour() 
                + ", minute=" + monthly.getMinute() + '}';
        result = monthly.toString();
        assertEquals(expectedResult, result);
    }
    
}
