/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appointmentsapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Cristy
 */
public class DailyAppointmentIT {
    
    public DailyAppointmentIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
//        System.out.println("main");
//        String[] args = null;
       
        DailyAppointment daily = new DailyAppointment("Trainer Workout", "Joe Trainer", 10, 30); 
        
        //test getters...
        //getDescription
        String expectedResult = "Trainer Workout";
        String result = daily.getDescription();
        assertEquals(expectedResult, result);
        
        //getName
        expectedResult = "Joe Trainer";
        result = daily.getName();
        assertEquals(expectedResult, result);
        
        //getHour
        int expectResult = 10;
        int resultNum = daily.getHour();
        assertEquals(expectResult, resultNum);
        
        //getMinute
        expectResult = 30;
        resultNum = daily.getMinute();
        assertEquals(expectResult, resultNum);
        
        //test toString()...
        expectedResult = "DailyAppointment{" + "description=" + daily.getDescription() + ", name=" 
                + daily.getName() + ", hour=" + daily.getHour() + ", minute=" + daily.getMinute() + '}';
        result = daily.toString();
        assertEquals(expectedResult, result);
    }
    
}
