/*
 * @author 5775423
 * 
 * Title: Appointments_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program stores different appointment objects into an
 *                  array and checks for appointments on a given date.
 */
package appointmentsapp;

//abstract super class named Appointment
public abstract class Appointment 
{
    //instance variables
    private String description;
    private String name;
    private int hour;
    private int minute;

    //getters
    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }
    
    //setters
    public void setDescription(String description) {
        this.description = description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }
    
    //abstract method
    public abstract boolean occursOn(int aYear, int aMonth, int aDay);
}
