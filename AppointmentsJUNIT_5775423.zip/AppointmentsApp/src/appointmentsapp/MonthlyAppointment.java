/*
 * @author 5775423
 * 
 * Title: Appointments_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program stores different appointment objects into an
 *                  array and checks for appointments on a given date.
 */
package appointmentsapp;

//subclass that extends Appointment
public class MonthlyAppointment extends Appointment
{
    //instance variables 
    private String description;
    private String name;
    private int day;
    private int hour;
    private int minute;
    
    //constructor to initialize instance variables
    public MonthlyAppointment(String description, String name, int day, int hour, int minute) {
        this.description = description;
        this.name = name;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
    }

    //getters
    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public int getDay() {
        return day;
    }
    
    @Override
    public int getHour() {
        return hour;
    }

    @Override
    public int getMinute() {
        return minute;
    }
    
    //setters
    public void setDescription(String description) {
        this.description = description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }
    
    //return attributes of monthly appointment
    @Override
    public String toString() {
        return "MonthlyAppointment{" + "description=" + description + ", name=" + name + ", day=" + day + ", hour=" + hour + ", minute=" + minute + '}';
    }
    
    //abstact method that returns a boolean if parameters match with certain objects
    public boolean occursOn(int aYear, int aMonth, int aDay)
    {
        //if the day of the month of monthly appointment equals day, return true
        if(day == aDay)
        {
            return true;
        }
        //otherwise, return false
        return false;
    }
}
