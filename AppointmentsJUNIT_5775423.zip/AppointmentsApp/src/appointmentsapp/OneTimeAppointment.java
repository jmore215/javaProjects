/*
 * @author 5775423
 * 
 * Title: Appointments_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program stores different appointment objects into an
 *                  array and checks for appointments on a given date.
 */
package appointmentsapp;

//subclass that extends Appointment
public class OneTimeAppointment extends Appointment
{
    //instance variables
    private String description;
    private String name;
    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;
    
    //constructor to initialize instance variables
    public OneTimeAppointment(String description, String name, int year, int month, int day, int hour, int minute) {
        this.description = description;
        this.name = name;
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
    }
    
    //getters
    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }
    
    //setters
    public void setDescription(String description) {
        this.description = description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setDay(int day) {
        this.day = day;
    }

    @Override
    public void setHour(int hour) {
        this.hour = hour;
    }

    @Override
    public void setMinute(int minute) {
        this.minute = minute;
    }
    
    //return attributes of one time appointment
    @Override
    public String toString() {
        return "OneTimeAppointment{" + "description=" + description + ", name=" + name + ", year=" + year + ", month=" + month + ", day=" + day + ", hour=" + hour + ", minute=" + minute + '}';
    }
    
    //abstact method that returns a boolean if parameters match with certain objects
    public boolean occursOn(int aYear, int aMonth, int aDay)
    {
        //if the passed year = the year in the one time appointment object...
        if(year ==  aYear)
        {
            //as well as both months...
            if(month == aMonth)
            {
                //as well as both days...
                if(day == aDay)
                {
                    //return true
                    return true;
                }
            }
        }
        //otherwise, return false
        return false;
    }
}
