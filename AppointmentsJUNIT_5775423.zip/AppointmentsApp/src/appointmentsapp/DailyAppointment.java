/*
 * @author 5775423
 * 
 * Title: Appointments_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program stores different appointment objects into an
 *                  array and checks for appointments on a given date.
 */
package appointmentsapp;

//subclass that extends Appointment
public class DailyAppointment extends Appointment
{
    //instance variables
    private String description;
    private String name;
    private int hour;
    private int minute;
    
    //constructor to initialize instance variables
    public DailyAppointment(String description, String name, int hour, int minute) {
        this.description = description;
        this.name = name;
        this.hour = hour;
        this.minute = minute;
    }
    
    //getters
    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    @Override
    public int getHour() {
        return hour;
    }

    @Override
    public int getMinute() {
        return minute;
    }
    
    //setters
    public void setDescription(String description) {
        this.description = description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }
    
    //return attributes of daily appointment
    @Override
    public String toString() {
        return "DailyAppointment{" + "description=" + description + ", name=" + name + ", hour=" + hour + ", minute=" + minute + '}';
    }
    
    //abstact method that returns a boolean if parameters match with certain objects
    public boolean occursOn(int aYear, int aMonth, int aDay)
    {
        //return true since there are no variables to compare with passed 
        //year, month, and day parameters.
        return true;
    }     
}
