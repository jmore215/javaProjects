/*
 * @author 5775423
 * 
 * Title: Appointments_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program stores different appointment objects into an
 *                  array and checks for appointments on a given date.
 */
package appointmentsapp;

//import scanner and arrays
import java.util.Scanner;
import java.util.Arrays;


public class AppointmentsApp 
{
    //global array of Appointments
    public Appointment[] myAppointments; 
    //global index variable
    public int currentIndex = -1;
    
    public static void main(String[] args) 
    {
        //instantiate driver class
        AppointmentsApp myApp = new AppointmentsApp();
        
        //variables for user input
        int appNum = 0;
        int menuOption = 0;
        String answer = "yes";
        
        //create keyboard object
        Scanner keyboard = new Scanner(System.in);
        
        /**
        * Create a menu loop as follows:
        * 
        * How many appointments do you wish to make? 3

            Please make a selection:
            1. One Time Appointment
            2. Daily Appointment 
            3. Monthly Appointment 
            * 
            * 
            * For Each option, request the appropriate data from the user, and then 
            * instantiate the appropriate class/subclass in the Appointment hierarchy
            * For each appointment made, you will add it to an array of appointments 
            * that you have created when you found out how many appts.
            * 
        * Once the menu LOOP is over, ask the user the following question in a Do-While LOOP:
            * What is the date you wish to look up in your Appointments' Calendar? 
                    Enter the month: 03
                    Enter the day: 15
                    Enter the year: 2017
                
                * (Display the result in the following format:)   
                * 
                * On 3 / 15 / 2017 you have the following appointments: 
                    Dentist appointment with Dr. Smith at 13:30
                    Piano Lessons with Ms. Katie at 17:30
                    Athletic Training with Ms. Jones at 10:00

                Do you wish to look up another date? 
                   (If they answer NO, exit the program with message)
                  “Thank  you for using your appointment calendar.”

                    (If they answer YES, continue to ask for another date to look up).
                   "What is the date you wish to look up in your Appointments' Calendar? "
                        etc.,.


        */
        
        //do while to validate that num of appointments is not less than 1
        do
        {
            System.out.print("How many appointments do you wish to make? ");
            appNum = keyboard.nextInt();
        }while(appNum < 1); 
        
        
        //for loop that will run for how many appointments there are
        for(int i = 0; i < appNum; i++)
        {
            //do while to validate that menuOption is an int of 1, 2, or 3
            do
            {
                //display menu and store input
                System.out.println("\nPlease make a selection: \n1. One Time Appointment\n2. Daily Appointment\n3. Monthly Appointment\n");
                menuOption = keyboard.nextInt();
                
                //display invalid message when input out of bounds
                if(menuOption < 1 || menuOption > 3)
                {
                    System.out.println("Invalid option! Enter either 1, 2, or 3.");
                } 
            }while(menuOption < 1 || menuOption > 3);
            
            //pass the number of appointments and menuOption into makeAppointments()
            myApp.makeAppointments(appNum, menuOption);
        }
        
        //display a message saying that all appointments have been made
        System.out.println("\n**********Thank you for making all of your appointments.**************\n");
        
        //call checkAppointments() method
        myApp.checkAppointments();
        
        //while loop that will keep running if the user wishes to look up 
        //another date
        while(answer.equalsIgnoreCase("yes"))
        {
            //nextLine for bug
            keyboard.nextLine();
            
            //prompt the user if they want to run the method again and store answer
            System.out.print("\nDo you wish to look up another date? ");
            answer = keyboard.nextLine();
            
            //if answer is yes...
            if(answer.equalsIgnoreCase("yes"))
            {
                //call method again
                myApp.checkAppointments();
                
                //message to user to help bypass bug and continue program
                System.out.println("\nPlease Press Enter Again!!!");
            }
            //if answer is anything other than yes...
            else
            {
                //display farewell message
                System.out.println("\nThank you for using your appointment calendar.");
            }
        }
    }
    
    //this method creates an array of appointment objects and stores it into
    //the global array
    public void makeAppointments(int appNum, int menuOption)
    {
        //variables to store user input
        String description, name;
        int year, month, day, hour, minute;
        
        //create keyboard object
        Scanner keyboard = new Scanner(System.in);
        
        //if the current index is unchanged from its original initialization...
        if(currentIndex == -1)
        {
            //set the size of the array using variable holding number of 
            //appointments
            myAppointments = new Appointment[appNum];
        }
        
        //if passed menu option =1 create a one time appointment object and store
        //it into array
        if(menuOption == 1)
        {
            //increment currentIndex by 1
            currentIndex++;
            
            //ask the user for the following information
            System.out.print("What is the description of your appointment? ");
            description = keyboard.nextLine();
            System.out.print("What is your person's name? ");
            name = keyboard.nextLine();
            System.out.print("What year is your appointment? (2017 - 2018) ");
            year = keyboard.nextInt();
            do
            {
                System.out.print("What month is your appointment? (1 - 12) ");
                month = keyboard.nextInt();
                
                if(month < 1 || month > 12)
                {
                    System.out.println("Invalid! Enter a number from 1 to 12.");
                }
            }while(month < 1 || month > 12);
            do
            {
                System.out.print("What day is your appointment? (1 - 31) ");
                day = keyboard.nextInt();
                
                if(day < 1 || day > 31)
                {
                    System.out.println("Invalid! Enter a number from 1 to 31.");
                }
            }while(day < 1 || day > 31);
            do
            {
                System.out.print("What is the hour of your appointment? (00 - 23) ");
                hour = keyboard.nextInt();
                
                if(hour < 0 || hour > 23)
                {
                    System.out.println("Invalid! Enter a number from 0 to 23.");
                }
            }while(hour < 0 || hour > 23);
            do
            {
                System.out.print("What is the minute of your appointment? (00 - 59) ");
                minute = keyboard.nextInt();
                
                if(minute < 0 || minute > 59)
                {
                    System.out.println("Invalid! Enter a number from 0 to 59. ");
                }
            }while(minute < 0 || minute > 59);
            
            //store information into a new object of a one time appointment
            OneTimeAppointment oneTime = new OneTimeAppointment(description, name, year, month, day, hour, minute);
            
            //store object into array at currentIndex
            myAppointments[currentIndex] = oneTime;
            
            //state that the appointment was added
            System.out.println("\nAppointment added with " + name 
                    + " on " + month + "/" + day + "/" + year + " at "
                    + hour + ":" + minute + ".");
        }
        
        //else if passed menu option =2 create a daily appointment object and 
        //store it into array
        else if(menuOption == 2)
        {
            //increment currentIndex by 1
            currentIndex++;
            
            //ask the user for the following information
            System.out.print("What is the description of your appointment? ");
            description = keyboard.nextLine();
            System.out.print("What is your person's name? ");
            name = keyboard.nextLine();
            do
            {
                System.out.print("What is the hour of your appointment? (00 - 23) ");
                hour = keyboard.nextInt();
            }while(hour < 0 || hour > 23);
            do
            {
                System.out.print("What is the minute of your appointment? (00 - 59) ");
                minute = keyboard.nextInt();
            }while(minute < 0 || minute > 59);
            
            //store information into a new object of a daily appointment
            DailyAppointment daily = new DailyAppointment(description, name, hour, minute);
            
            //store object into array at currentIndex
            myAppointments[currentIndex] = daily;
            
            //state that the appointment was added
            System.out.println("\nAppointment added with " + name 
                    + " Daily " + " at " + hour + ":" + minute + ".");
        }
        
        //else if passed menu option =3 create a monthly appointment object and 
        //store it into array
        else if(menuOption == 3)
        {
            //increment currentIndex by 1
            currentIndex++;
            
            //ask the user for the following information
            System.out.print("What is the description of your appointment? ");
            description = keyboard.nextLine();
            System.out.print("What is your person's name? ");
            name = keyboard.nextLine();
            do
            {
                System.out.print("What day of the month is your appointment? (1 - 31) ");
                day = keyboard.nextInt();
                
                if(day < 1 || day > 31)
                {
                    System.out.println("Invalid! Enter a number from 1 to 31.");
                }
            }while(day < 1 || day > 31);
            do
            {
                System.out.print("What is the hour of your appointment? (00 - 23) ");
                hour = keyboard.nextInt();
                
                if(hour < 0 || hour > 23)
                {
                    System.out.println("Invalid! Enter a number from 0 to 23.");
                }
            }while(hour < 0 || hour > 23);
            do
            {
                System.out.print("What is the minute of your appointment? (00 - 59) ");
                minute = keyboard.nextInt();
                
                if(minute < 0 || minute > 59)
                {
                    System.out.println("Invalid! Enter a number from 0 to 59.");
                }
            }while(minute < 0 || minute > 59);
            
            //store information into a new object of a monthly appointment
            MonthlyAppointment monthly = new MonthlyAppointment(description, name, day, hour, minute);
            
            //store object into array at currentIndex
            myAppointments[currentIndex] = monthly;
            
            //state that the appointment was added
            System.out.println("\nAppointment added with " + name 
                    + " Monthly " + " on day " + day + " at " 
                    + hour + ":" + minute + ".");
        }
    }
    
    //this method asks the user for a given date to check for any appointments
    public void checkAppointments()
    {
        //
        //String monthS = "", dayS = "", yearS = "";
        int month, day, year;
        
        //create keyboard object
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("What is the date you wish to look up in your Appointments' Calendar?");
        
        //prompt the user for month
        System.out.print("Enter the month: ");
        month = keyboard.nextInt();
        
        //prompt the user for day
        System.out.print("Enter the day: ");
        day = keyboard.nextInt();
        
        //prompt the user for year
        System.out.print("Enter the year: ");
        year = keyboard.nextInt();
        
        //print a message displaying that any appointments occurring on that
        //date will be shown
        System.out.println("\nOn " + month + "/" + day + "/" 
                        + year + " you have the following appointments: ");
        
        //for loop to go through array of appointments
        for(int i = 0; i < myAppointments.length; i++)
        {
            //call occurs on and if appointments at i returns true, print object
            if(myAppointments[i].occursOn(year, month, day) == true)
            {
                //use getters to print appointment
                System.out.println(myAppointments[i].getDescription() 
                        + " with " + myAppointments[i].getName() 
                        + " at " + myAppointments[i].getHour() 
                        + ":" + myAppointments[i].getMinute());
            }
        }
    }
}
