/*
 * @author 5775423
 * 
 * Title: Lab10b_5775423
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program asks the user to create an array and change the
 *              content in any index.
 */
package lab10b_5775423;

//import Scanner and ArrayList
import java.util.Scanner;
import java.util.ArrayList;

public class Lab10b_5775423 
{
    //global ArrayList and global variable for array length
    public static ArrayList <String> data;
    public static int userInput;
    
    public static void main(String[] args) 
    {
        //Task 1a.
//			ArrayList<String> arr = new ArrayList<>();
//			arr.set(0, "This is a String");
//
//			Exception: IndexOutOfBoundsException
//
//			What caused the error:The array list has a size of 0 which is out of bounds.
//
//			How to Fix It: Create a size for the array list.
//			
//			--------------------------------------------------------------------
//			
//			//Task 1b.
//			ArrayList<String> arr = new ArrayList<>();
//			arr.add("Apple");
//			arr.add("Banana");
//			arr.add("Carrot");
//			arr.add(6, "Pineapple Pizza");
//
//			Exception: IndexOutOfBoundsException
//			
//			What caused the error: It wanted to add something at index 6 but index 6 doesn't exist. There is only a size of 3.
//
//			How to Fix It: You can add "Pineapple Pizza" at index 0,1, or 2 OR you can keep adding other string literals until there is a size of 7.
//
//			
//			--------------------------------------------------------------------
//			
//			//Task 1c.
//			ArrayList<String> arr = new ArrayList<>();
//			arr.add("Apple");
//			arr.add("Banana");
//			arr.add("Carrot");
//			arr.add(3, "Regular Pizza");
//
//			Exception: No exception (build successful)
//			
//			What caused the error: No error. Strings are added into array list.
//
//			How to Fix It: No error.
//			--------------------------------------------------------------------
//			
//			//Task 1d.
//			ArrayList<String> arr = new ArrayList<>();
//			arr.add("Apple");
//			arr.add("Banana");
//			arr.add("Carrot");
//			arr.get(1) = "Blood Orange";
//
//			Exception: RuntimeException
//			
//			What caused the error: There is no variable that it's being stored into to get.
//
//			How to Fix It: Create a variable so that it gets the value at a specific index.
//			
//			--------------------------------------------------------------------
//			
//			//Task 1e.
//			ArrayList<String> arr = new ArrayList<>();
//			arr.add("Apple");
//			arr.add("Banana");
//			arr.add("Carrot");
//			arr.get(arr.size());
//
//			Exception: IndexOutOfBoundsException
//			
//			What caused the error: The index is equal to the size. (Index of 3 and size of 3) You can't get a size, you can only get the index.
//
//			How to Fix It: Increase size of array list or get index of 0,1 or 2.
//			
//			--------------------------------------------------------------------
//			
//			//Task 1f.
//			ArrayList<String> arr = new ArrayList<>();
//			arr.add("Apple");
//			arr.add("Banana");
//			arr.add("Carrot");
//			arr.remove("Potato");
//
//			Exception: No exception
//			
//			What caused the error: No error.
//
//			How to Fix It: No error.
        
        //Task 2
        
        //Scanner for user input
        Scanner keyboard = new Scanner(System.in);
        
        //ask the user what length of the array should be and store it in global variable
        System.out.println("How many values would you like to store in the array list?");
        userInput = keyboard.nextInt();
        
        //set ArrayList to the user's desired size
        data = new ArrayList <String>(userInput);
        
        //call method to ask user to set values for each position in the array
        populateArrayList();
        
        //call method to ask the user if they want to change any value in the array.
        //      if so, ask what they want to change it to.
        changeArrayList();
    }
    
    //this method asks the user to set values for each position in the array
    public static void populateArrayList()
    {
        for(int i = 0; i < userInput; i++)
        {
            String input;
            
            //scanner object for user input
            Scanner keyboard = new Scanner(System.in);
            
            //ask for a value to enter at each postion of i 
            System.out.println("Input value " + i + ": ");
            input = keyboard.nextLine();
            
            //use the .add method to put the input in the ArrayList
            data.add(input);
        }
        
        //for loop to print values in ArrayList
        for(int i = 0; i < userInput; i++)
        {
            System.out.println("Values in Array List, Position " + i + ": " + data.get(i));
        }
    }
    
    //this method asks the user if they want to change any value in the array.
    public static void changeArrayList()
    {
        int position;
        String answer, value;
        
        //Scanner object for user input
        Scanner keyboard = new Scanner(System.in);
        
        //ask the user what position in the ArrayList would they like to change
        System.out.println("What position in the array list do you want to change?");
        position = keyboard.nextInt();
        
        //show the value at the desired position
        System.out.println("Value at position " + position + ": " + data.get(position));
        
        keyboard.nextLine();
        
        //ask if they want to change it
        System.out.println("Do you want to change that value?");
        answer = keyboard.nextLine();
        
        //if statement if the answer is yes
        if(answer.equalsIgnoreCase("yes"))
        {
            //ask what the new value should be changed to
            System.out.println("What do you want to change it to?");
            value = keyboard.nextLine();
            
            //store it in the ArrayList
            data.set(position,value);
        }
        
        //read all the values in the altered ArrayList
        for(int i  = 0; i < userInput; i++)
        {
            System.out.println("Values in Changed Array List, Position " + i + ": " + data.get(i));
        }
    
    
    }
    
}
