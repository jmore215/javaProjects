/*
 * @author 5775423
 * 
 * Title: FinalProgramV1_5775423
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program reads a file called foods and uses the
 *              calories to find the average, sum, and lowest cal
 *              food
 */
package finalprogramexamv1;


public class Food 
{
    //instance variables
    private String foodName;
    private int calories;
    
    //constructor
    public Food(String foodName, int calories) 
    {
        this.foodName = foodName;
        this.calories = calories;
    }
    
    //getters
    public String getFoodName() 
    {
        return foodName;
    }

    public int getCalories() 
    {
        return calories;
    }
    
    //setters
    public void setFoodName(String foodName) 
    {
        this.foodName = foodName;
    }

    public void setCalories(int calories) 
    {
        this.calories = calories;
    }
    
    //toString to print all attributes
    @Override
    public String toString() 
    {
        return "Food{" + "foodName=" + foodName + ", calories=" + calories + '}';
    }
}
