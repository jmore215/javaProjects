/*
 * @author 5775423
 * 
 * Title: FinalProgramV1_5775423
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program reads a file called foods and uses the
 *              calories to find the average, sum, and lowest cal
 *              food
 */
package finalprogramexamv1;

//import scanner and io
import java.io.*;
import java.text.DecimalFormat;
import java.util.Scanner;

public class FinalProgramExamV1 
{
    // decalre global array of foods
    public static Food[] foods;
    
    public static void main(String[] args) throws IOException
    {
        //Call methods into main
        createArrayOfFoods();
        printArrayOfFoods(); 
        computeAndPrintStats();
    }
    
    //this method read the text doc and stores it into the array
    public static void createArrayOfFoods()throws IOException
    {
        //Create variables for each value in text doc and 
        // and initialize counter variable to 0
        String food;
        int calories;
        int numOfFood = 0;
        Food aFood;
        
        //open file and scan
        File aFile = new File("foods.txt");
        Scanner inFile = new Scanner(aFile);
        
        //count how many foods there are
        while(inFile.hasNext())
        {
            numOfFood++;
            inFile.nextLine();
        }
        //close file
        inFile.close();
        
        //set the size of the array to how many foods there are
        foods = new Food[numOfFood];
        
        //open file again by initializing file and scanner
        aFile = new File("foods.txt");
        inFile = new Scanner(aFile);
        
        //read the text doc using for loop
        for(int i = 0; inFile.hasNext() && i < foods.length; i++)
        {
            food = inFile.next();
            calories = inFile.nextInt();
            
            //store the food into aFood going by order of constructor
            aFood = new Food(food, calories);
            
            //store the food into the array at that index
            foods[i] = aFood;
        }
        //close file
        inFile.close();
    }
    
    //this method prints all of the foods
    public static void printArrayOfFoods()
    {
        //for loop to print all foods in array 
        for(int i = 0; i < foods.length; i++)
        {
            System.out.println(foods[i]);
        }
    }
    
    //this method calculates the average, sum, lowest calorie food
    public static void computeAndPrintStats()
    {
        //set the variables to find lowest cal food equal to the
        //first position in the array
        int leastCalFood = foods[0].getCalories();
        int leastCalFoodIndex = 0;
        
        //double the average and set the sum equal to the first value
        //in the array
        double average;
        int sum = foods[0].getCalories();
        
        //for loop starts at position 1 and ends at length of the array
        //to calculate the sum and lowest cal food
        for(int i = 1; i < foods.length; i++)
        {
            //if statement to find lowest cal food
            if(foods[i].getCalories() < leastCalFood)
            {
                //if the food at position i is lower than the
                //lowest cal food, set it to that index
                leastCalFood = foods[i].getCalories();
                leastCalFoodIndex = i;
            }
            
            //add each food at each index into the sum
            sum += foods[i].getCalories();
        }
        
        //calculate average and cast sum into double
        average = (double)sum / foods.length;
        
        //decimal format for average
        DecimalFormat df = new DecimalFormat("#0.00");
        
        //print the sum, average, and lowest cal food
        System.out.println("The food with the lowest calories is: " + foods[leastCalFoodIndex]);
        System.out.println("The sum of all calories: " + sum);
        System.out.println("The average of all calories is: " + df.format(average));
    }
}
