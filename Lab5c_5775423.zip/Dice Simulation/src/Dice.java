/**
 * @author 5775423
 * 
 * Title: Lab5c_5775423
 * Semester:COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This class simulates rolling a pair of dice 10,000 times and counts the
 * number of times doubles are rolled for each number using different loops.
 */

//import random
import java.util.Random;

public class Dice
{
    //instance variables
    private int die1;
    private int die2;
    
    //constructor
    public Dice()
    {
        die1 = 1;
        die2 = 1;
    }
    
    //to roll random dice
    public void rollDice()
    {
        //create random object
        Random myRan = new Random();
        
        //store random numbers into die variables
        die1 = myRan.nextInt(6) + 1;
        die2 = myRan.nextInt(6) + 1;
    }
    
    //getters
    public int getDie1()
    {
        return die1;
    }
    
    public int getDie2()
    {
        return die2;
    }
    
    //setters
    public void setDie1(int aDie1)
    {
        die1 = aDie1;
    }
    
    public void setDie2(int aDie2)
    {
        die2 = aDie2;
    }
    
    //return the values in both dice
    public String toString()
    {
         return "You rolled a ..." + die1 + " and " + die2;   
    }
}
