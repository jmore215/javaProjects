/**
 * @author 5775423
 * 
 * Title: Lab5c_5775423
 * Semester:COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This class simulates rolling a pair of dice 10,000 times and counts the
 * number of times doubles are rolled for each number using different loops.
 */

//import JOptionPane
import javax.swing.JOptionPane;

//import Random
import java.util.Random; //to use the random number generator

public class DiceSimulation
{
    static final int NUMBER = 10000; //the number of times to roll the dice
    //a random number generator used in simulating rolling a dice
    //static Random generator = new Random();

    static int die1Value; // number of spots on the first die
    static int die2Value; // number of spots on the second die
    static int count = 0; // number of times the dice were rolled
    static int ones = 0; // number of times double one is rolled
    static int twos = 0; // number of times double two is rolled
    static int threes = 0; // number of times double three is rolled
    static int fours = 0; // number of times double four is rolled
    static int fives = 0; // number of times double five is rolled
    static int sixes = 0; // number of times double six is rolled

    public static void main(String[] args)
    {
        //ENTER YOUR METHOD CALLS HERE
        //call method that uses a while loop
        rollDiceAndTabulateWhile();
        //display what loop is being displayed
        JOptionPane.showMessageDialog(null,"*******Using While Loop...*******");
        //call summarizeResults to display the kinds of doubles rolled
        summarizeResults();
        //clear the numbers in the counter variables
        clearCounters();
        
        //call method that uses a do-while loop
        rollDiceAndTabulteDoWhile();
        //display what loop is being displayed
        JOptionPane.showMessageDialog(null,"*******Using Do-While Loop...*******");
        //call summarizeResults to display the kinds of doubles rolled
        summarizeResults();
        //clear the numbers in the counter variables
        clearCounters();
        
        //call method that uses a for loop
        rollDiceAndTabulteFor();
        //display what loop is being displayed
        JOptionPane.showMessageDialog(null,"*******Using For Loop...*******");
        //call summarizeResults to display the kinds of doubles rolled
        summarizeResults();
    }
    //while loop method
    public static void rollDiceAndTabulateWhile()
    {
        //Complete task 2 here
        
        //create a dice object
        Dice aNewDice = new Dice();
        
        //while loop to roll and count dice and stop when it has been rolled 10000 times
        while(NUMBER > count)
        {
            //roll the dice for the object
            aNewDice.rollDice();
            //call the getter for die 1 and store into die1Value
            die1Value = aNewDice.getDie1();
            //call the getter for die 2 and store into die2Value
            die2Value = aNewDice.getDie2();
            
            //if-else if to compare the numbers after the dice rolled 
            if(die1Value==1 && die2Value==1)
            {
                //add 1 each time there are double ones
                ones+=1;
            }
            else if(die1Value==2 && die2Value==2)
            {
                //add 1 each time there are double twos
                twos+=1;
            }
            else if(die1Value==3 && die2Value==3)
            {
                //add 1 each time there are double threes
                threes+=1;
            }
            else if(die1Value==4 && die2Value==4)
            {
                //add 1 each time there are double fours
                fours+=1;
            }
            else if(die1Value==5 && die2Value==5)
            {
                //add 1 each time there are double fives
                fives+=1;
            }
            else if(die1Value==6 && die2Value==6)
            {
                //add 1 each time there are double sixes
                sixes+=1;
            }
            //increment count by 1 each time the dice is rolled
            count+=1;
        }
    }
    //do-while loop method
    public static void rollDiceAndTabulteDoWhile()
    {
        //Complete task 3 here
        
        //create a dice object
        Dice aNewDice = new Dice();
        
        //do-while loop to roll and count dice
        do
        {
            //roll the dice for the object
            aNewDice.rollDice();
            //call the getter for die 1 and store into die1Value
            die1Value = aNewDice.getDie1();
            //call the getter for die 2 and store into die2Value
            die2Value = aNewDice.getDie2();
            
            //if-else if to compare the numbers after the dice rolled
            if(die1Value==1 && die2Value==1)
            {
                //add 1 each time there are double ones
                ones+=1;
            }
            else if(die1Value==2 && die2Value==2)
            {
                //add 1 each time there are double twos
                twos+=1;
            }
            else if(die1Value==3 && die2Value==3)
            {
                //add 1 each time there are double threes
                threes+=1;
            }
            else if(die1Value==4 && die2Value==4)
            {
                //add 1 each time there are double fours
                fours+=1;
            }
            else if(die1Value==5 && die2Value==5)
            {
                //add 1 each time there are double fives
                fives+=1;
            }
            else if(die1Value==6 && die2Value==6)
            {
                //add 1 each time there are double sixes
                sixes+=1;
            }
            //increment count by 1 each time the dice is rolled
            count+=1;
            
        }while(NUMBER != count); //keep doing if the number is not equal to the count
    }
    //for loop method
    public static void rollDiceAndTabulteFor()
    {
        //Complete task 4 here
        
        //create a dice object
        Dice aNewDice = new Dice();
        
        //for loop to roll and count dice
        for(count = 1; count<=NUMBER; count++)
        {
            //roll the dice for the object
            aNewDice.rollDice();
            //call the getter for die 1 and store into die1Value
            die1Value = aNewDice.getDie1();
            //call the getter for die 2 and store into die2Value
            die2Value = aNewDice.getDie2();
            
            //if-else if to compare the numbers after the dice rolled
            if(die1Value==1 && die2Value==1)
            {
                //add 1 each time there are double ones
                ones+=1;
            }
            else if(die1Value==2 && die2Value==2)
            {
                //add 1 each time there are double twos
                twos+=1;
            }
            else if(die1Value==3 && die2Value==3)
            {
                //add 1 each time there are double threes
                threes+=1;
            }
            else if(die1Value==4 && die2Value==4)
            {
                //add 1 each time there are double fours
                fours+=1;
            }
            else if(die1Value==5 && die2Value==5)
            {
                //add 1 each time there are double fives
                fives+=1;
            }
            else if(die1Value==6 && die2Value==6)
            {
                //add 1 each time there are double sixes
                sixes+=1;
            }    
        }    
    }
    
    //method to reset all the counters to 0
    public static void clearCounters()
    {
        //set all counter variables equal to 0
        ones = 0;
        twos = 0;
        threes = 0;
        fours = 0;
        fives = 0;
        sixes = 0;
        count = 0;
    }
    
    //method that displays the results
    public static void summarizeResults()
    {
        //use JOptionPane to display the results
        JOptionPane.showMessageDialog(null, "You rolled double ones " + ones
                + " out of " + NUMBER + " rolls.");
        JOptionPane.showMessageDialog(null, "You rolled double twos " + twos
                + " out of " + NUMBER + " rolls.");
        JOptionPane.showMessageDialog(null, "You rolled double threes " + threes
                + " out of " + NUMBER + " rolls.");
        JOptionPane.showMessageDialog(null, "You rolled double fours " + fours
                + " out of " + NUMBER + " rolls.");
        JOptionPane.showMessageDialog(null, "You rolled double fives " + fives
                + " out of " + NUMBER + " rolls.");
        JOptionPane.showMessageDialog(null, "You rolled double sixes " + sixes
                + " out of " + NUMBER + " rolls.");
    }
}
