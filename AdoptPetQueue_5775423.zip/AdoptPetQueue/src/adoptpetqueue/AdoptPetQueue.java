/*
 * @author 5775423
 * 
 * Title: AdoptPetQueue_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program simulates an animal shelter by showing a menu 
 *                  to adopt and/or donate cats and dogs.
 */
package adoptpetqueue;

import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;


public class AdoptPetQueue 
{
    //global queues and scanner object
    public Scanner keyboard = new Scanner(System.in);
    public Queue<Pet> myCatQueue = new LinkedList<Pet>();
    public Queue<Pet> myDogQueue = new LinkedList<Pet>();
    public PriorityQueue<Pet> myAnimalsQueue = new PriorityQueue<Pet>();
    
    public static void main(String[] args) 
    {
        //instantiate driver
        AdoptPetQueue myPQ = new AdoptPetQueue();
        
        //variable for user choice
        int userChoice = 0;
        do
        {
            //display menu to switch user choice
            userChoice = myPQ.displayMenu();
            
            //switch for user choice
            switch(userChoice)
            {
                //option to donate cat
                case 1: 
                    myPQ.enqueueCats();
                    break;
                //option to donate dog
                case 2:
                    myPQ.enqueueDogs();
                    break;
                //option to adopt cat
                case 3:
                    myPQ.dequeueCats();
                    break;
                //option to adopt dog
                case 4:
                    myPQ.dequeueDogs();
                    break;
                //option to adopt oldest pet
                case 5:
                    myPQ.dequeueOldest();
                    break;
                //option to exit
                case 6:
                    System.out.println("Goodbye!!!");
                    break;
            }
        }while(userChoice != 6); //keep looping until user exits
    } 
    
    //this method displays a menu and validates the input
    public int displayMenu()
    {
        int userChoice = 0;
        boolean validChoice = false;
        
        //do while to keep looping till menu option is valid
        do
        {
            try
            {
                //display menu
                System.out.println("1. Donate a Cat\n"
                        + "2. Donate a Dog\n"
                        + "3. Adopt a Cat\n"
                        + "4. Adopt a Dog\n"
                        + "5. Adopt Oldest Pet\n"
                        + "6. Exit");

                //store user choice
                userChoice = keyboard.nextInt();

                //dont loop again if choice is valid
                validChoice = true;
                
                //loop again if the number is out of range
                if(userChoice < 1 || userChoice > 6)
                {
                    System.out.println("Invalid Number! Enter a number from 1 to 6.");
                    validChoice = false;
                }
            }
            //catch the exception and loop again if input is not a number
            catch(InputMismatchException e)
            {
                System.out.println("Invalid Input! Enter a number from 1 to 6.");
                
                validChoice = false;
                
                keyboard.nextLine();
            }
        }while(!validChoice);
        
        return userChoice;
    }
    
    //this method adds a cat to the cat and animal queue
    public void enqueueCats()
    {
        String name, species;
        int dateOfBirth;
        Pet aCat;
        
        keyboard.nextLine();
        
        //ask for characteristics of the cat
        System.out.print("What is the name of the cat? ");
        name = keyboard.nextLine();
        
        //cat is a species
//        System.out.print("What is the species of the cat? ");
//        species = keyboard.nextLine();
        
        System.out.print("What is cat's date of birth(yyyymmdd)? ");
        dateOfBirth = keyboard.nextInt();
        
        //create a new cat object
        aCat = new Pet(name, "cat", dateOfBirth);
        
        //add the cat to the cat queue and animal queue
        myCatQueue.add(aCat);
        myAnimalsQueue.add(aCat);
    }
    
    //this method removes a cat from the cat and animal queue
    public void dequeueCats()
    {
        //if the queue is not empty, remove a cat to adopt from both queues
        if(!myCatQueue.isEmpty())
        {
            myAnimalsQueue.remove(myCatQueue.peek());
            System.out.println(myCatQueue.remove());
        }
        //if there are no more cats, display message
        else
        {
            System.out.println("No cats to adopt.");
        }
    }
    
    //this method adds a dog to the dog and animal queue
    public void enqueueDogs()
    {
        String name, species;
        int dateOfBirth;
        Pet aDog;
        
        keyboard.nextLine();
        
        //ask for characteristics of the dog
        System.out.print("What is the name of the dog? ");
        name = keyboard.nextLine();
        
        //dog is a species
//        System.out.print("What is the species of the dog? ");
//        species = keyboard.nextLine();
        
        System.out.print("What is dog's date of birth(yyyymmdd)? ");
        dateOfBirth = keyboard.nextInt();
        
        //create a new dog object
        aDog = new Pet(name, "dog", dateOfBirth);
        
        //add the dog to the dog queue and animal queue
        myDogQueue.add(aDog);
        myAnimalsQueue.add(aDog);
    }
    
    //this method removes a dog from the cat and animal queue
    public void dequeueDogs()
    {
        //if the queue is not empty, remove a dog to adopt from both queues
        if(!myDogQueue.isEmpty())
        {
            myAnimalsQueue.remove(myDogQueue.peek());
            System.out.println(myDogQueue.remove());
        }
        //if there are no more dogs, display message
        else
        {
            System.out.println("No dogs to adopt.");
        }
    }
    
    //this method is removes the oldest animal from the animal and corresponding
    // species queues
    public void dequeueOldest()
    {
        PriorityQueue<Pet> myNewAnimals = new PriorityQueue<Pet>(myAnimalsQueue);
        
        //create a pet object
        Pet removePet;
//        while(!myNewAnimals.isEmpty())
//        {
//            System.out.println(myNewAnimals.remove());
//        }
        
        //prepare for removal if the queue is not empty
        if(!myAnimalsQueue.isEmpty())
        {
            //store the oldest pet from the animals queue
            removePet = myAnimalsQueue.peek();
            
            //remove the oldest animal for adoption from animals queue
            System.out.println(myAnimalsQueue.remove());
            
            //if the species was a cat, remove it from the cat queue
            if(removePet.getSpecies().equalsIgnoreCase("cat"))
            {
                myCatQueue.remove(removePet);
            }
            //else if the species was a dog, remove it from the dog queue
            else if(removePet.getSpecies().equalsIgnoreCase("dog"))
            {
                myDogQueue.remove(removePet);
            }
        }
        //otherwise display that there are no more pets to adopt
        else
        {
            System.out.println("No more pets to adopt!");
        }
    } 
}