/*
 * @author 5775423
 * 
 * Title: AdoptPetQueue_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program simulates an animal shelter by showing a menu 
 *                  to adopt and/or donate cats and dogs.
 */
package adoptpetqueue;

//implement compare for each pet's D.O.B.
public class Pet implements Comparable<Pet>
{
    //instance variables
    private String name;
    private String species;
    private int dateOfBirth;

    //constructor
    public Pet(String name, String species, int dateOfBirth) {
        this.name = name;
        this.species = species;
        this.dateOfBirth = dateOfBirth;
    }

    //getters
    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    public int getDateOfBirth() {
        return dateOfBirth;
    }

    //setters
    public void setName(String name) {
        this.name = name;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public void setDateOfBirth(int dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    //toString
    @Override
    public String toString() {
        return "Pet{" + "name=" + name + ", species=" + species + ", dateOfBirth=" + dateOfBirth + '}';
    }
    
    //compareTo for each pets' date of birth
    public int compareTo(Pet otherPet)
    {
       if (this.dateOfBirth > otherPet.dateOfBirth)
       {    
           return 1;
       }
       else if (this.dateOfBirth == otherPet.dateOfBirth)
       {
          return 0; 
       }
       else
       {
           return -1;
       }
    }
}
