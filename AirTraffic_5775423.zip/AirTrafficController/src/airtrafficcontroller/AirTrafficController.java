/*
 * @author 5775423
 * 
 * Title: AirTraffic_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program sorts an array of points from a file and finds
 *                  the shortest distance between them.
 */
package airtrafficcontroller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;


public class AirTrafficController 
{
    //global array for coordinates
    Location[] myLocations;
    
    public static void main(String[] args) 
    {
        //instantiate driver
        AirTrafficController myATC = new AirTrafficController();
        
        //try and catch block for calling each method
        try
        {
            myATC.processFile();
            System.out.println("Unsorted array:");
            myATC.printArray();
            myATC.selectionSort();
            System.out.println("\nSorted array:");
            myATC.printArray();
            myATC.findMinDist(); 
        }
        catch (Exception e)
        {
            System.out.println("Sorry, file corrupted.  Cannot proceed. Contact Support"); 
        }
    }
    
    //method to process and read a file with coordinates
    public void processFile() throws Exception
    {
        //variables for reading and processing the file
        int arraySize;
        int x, y;
        int index = 0;
        Location aLocation;
        
        boolean tryAgain = true;
        Scanner keyboard = new Scanner(System.in);
        String fileName;
        File aFile = null;
        Scanner inFile = null;
        
        //do while to keep looping until a valid file is read
        do
        {
           try
           {
               //ask for input file name and store it
               System.out.println("What is the name of the input file?");
               fileName = keyboard.nextLine();
               //prepare to read and scan file
               aFile = new File(fileName);
               inFile = new Scanner(aFile);
               //if no file not found exception was thrown, then dont loop again
               tryAgain = false;
           }
           catch (FileNotFoundException e)
           {
               //ask the user to enter a valid file name and loop again
               System.out.println("Please try to enter a different file name.");
               tryAgain = true;
           }
        }while (tryAgain);
        
        inFile.useDelimiter(", |\\r\\n");
        
        //try and catch for reading the first line of file holding num of records
        try
        {
            //read the first line for size
            arraySize = inFile.nextInt();
            inFile.nextLine();
            //set the size of the array to the number that was read
            myLocations = new Location[arraySize];
        }
        catch(Exception e)
        {
            throw new Exception("File is corrupt");
        }
        
        //read file in while loop
        while (inFile.hasNext())
        {
            try
            {
                //read each record - using a Loop
                x = inFile.nextInt();
                y = inFile.nextInt();
                //create a Loc object
                aLocation = new Location(x, y);
                
                //add it to the array
                myLocations[index] = aLocation;
                //increment index
                index++;
            }
            //if the current coordinates have bad data, skip to next record
            catch (InputMismatchException e)
            {
                inFile.nextLine();
            }
            catch (Exception e)
            {
                throw new Exception("File is corrupt");
            }
        } 
    }
    
    //method to print the array
    public void printArray()
    {
        for(int i = 0; i < myLocations.length; i++)
        {
            System.out.println(myLocations[i]);
        }
    }
    
    //this method goes through the array and calls methods
    public void selectionSort()
    {
        for(int i = 0; i < myLocations.length - 1; i++)
        {
            int minPos = minimumPosition(i);
            swap(minPos, i);
        }
    }
    
    //this method uses compare to in preparation for swapping
    public int minimumPosition(int from)
    {
        int minPos = from;
        
        for(int i = from + 1; i < myLocations.length; i++)
        {
            if(myLocations[i].compareTo(myLocations[minPos]) == -1)
            {
                minPos = i;
            }
        }
        return minPos;
    }
    
    //this method switches the locations of each set of coordinates
    public void swap(int minPos, int i)
    {
        Location temp = myLocations[minPos];
        myLocations[minPos] = myLocations[i];
        myLocations[i] = temp;
    }
    
    //this method displays which 2 sets of coordinates are closest to each other
    public void findMinDist()
    {
        //initialize min dist to be dist between location at 0 and location at 1
        //loop that looks at the rest of the points in the array
        //compare the dist to min dist, and if the dist is smaller than min dist
        //   save dist 
        
        double minDist = Math.sqrt(Math.pow((myLocations[1].getxLoc()- myLocations[0].getxLoc()), 2) + Math.pow((myLocations[1].getyLoc() - myLocations[0].getyLoc()),2));
        double aDist;
        Location loc1 = myLocations[0];
        Location loc2 = myLocations[1];
        
        //for loop to find the lowest distance of all coordinates
        for(int i = 1; i < myLocations.length-1; i++)
        {
            //use distance formula
            aDist = Math.sqrt(Math.pow((myLocations[i+1].getxLoc() - myLocations[i].getxLoc()), 2) + Math.pow((myLocations[i+1].getyLoc() - myLocations[i].getyLoc()), 2));
            //if the dist is lower, store it
            if(aDist < minDist)
            {
                minDist = aDist;
                loc1 = myLocations[i];
                loc2 = myLocations[i+1];
            }
        }
        
        //display the lowest distance between 2 points and display those points
        System.out.println("Alert! The smallest distance between 2 planes is: " + minDist);
        System.out.println("The 2 planes are located at: ");
        System.out.println("Plane 1 = " + loc1);
        System.out.println("Plane 2 = " + loc2);
    }
}
