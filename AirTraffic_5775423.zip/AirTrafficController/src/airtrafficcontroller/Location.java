/*
 * @author 5775423
 * 
 * Title: AirTraffic_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program sorts an array of points from a file and finds
 *                  the shortest distance between them.
 */
package airtrafficcontroller;

public class Location implements Comparable<Location> 
{
    //instance variables
    private int xLoc;
    private int yLoc;
    
    //constructor
    public Location(int xLoc, int yLoc) {
        this.xLoc = xLoc;
        this.yLoc = yLoc;
    }

    //getters and setters
    public int getxLoc() {
        return xLoc;
    }

    public void setxLoc(int xLoc) {
        this.xLoc = xLoc;
    }

    public int getyLoc() {
        return yLoc;
    }

    public void setyLoc(int yLoc) {
        this.yLoc = yLoc;
    }

    @Override
    public String toString() {
        return "Location{" + "xLoc=" + xLoc + ", yLoc=" + yLoc + '}';
    }
    
    //compareTo to sort coordinates
    public int compareTo(Location otherLoc)
    {
        if (this.xLoc < otherLoc.xLoc)
            return -1;
        else if (this.xLoc > otherLoc.xLoc)
            return 1;
        else
            return 0;
    }
    
}
