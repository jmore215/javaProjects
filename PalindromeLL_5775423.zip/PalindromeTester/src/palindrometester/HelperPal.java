/*
 * @author 5775423
 * Title: PalindromeLL_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads a file of strings and checks if each string
 *                  is a palindrome using linked lists and iterators.
 */
package palindrometester;

import java.util.LinkedList;
import java.util.ListIterator;


public class HelperPal 
{
    //method to call helper methods and return a boolean result
    public boolean isPalindrome(LinkedList<String> aLL)
    {
       //create a local linked list to store the reversed string
       LinkedList aLL2;
       
       //store the method that returns reversed linked list
       aLL2 = reverse(aLL);
       
       //return boolean
       return isEqual(aLL, aLL2); 
    }
    
    //method to reverse a linked list
    public LinkedList<String> reverse(LinkedList<String> inputLL)
    {
        //create a linked list
        LinkedList<String> aLL2 = new LinkedList<String>();
        //create an iterator
        ListIterator<String> iter = inputLL.listIterator();
        
        //while loop to add each element to the beginning of another linked list
        while(iter.hasNext())
        {
            aLL2.addFirst(iter.next());
        }
        
        //return the reversed linked list
        return aLL2;
    }
    
    //this method returns whether the string is a palindrome or not
    public boolean isEqual(LinkedList<String> aLL1, LinkedList<String> aLL2)
    {
        
        boolean flag = true;
        ListIterator<String> iterLL1 = aLL1.listIterator();
        ListIterator<String> iterLL2 = aLL2.listIterator();
        
        String letter1;
        String letter2;
        
        //while loop to iterate through the linked lists
        while(iterLL1.hasNext() && iterLL2.hasNext() && flag == true) 
        {
            letter1 = iterLL1.next();
            letter2 = iterLL2.next();
            
            //as long as each element equals each other, flag = true
            if(letter1.equalsIgnoreCase(letter2))
            {
                flag = true;
            }
            //otherwise, return false 
            else
            {
                flag = false;
            }
        }
        //return the result
        return flag;
    }
}
