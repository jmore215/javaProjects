/*
 * @author 5775423
 * Title: PalindromeLL_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program reads a file of strings and checks if each string
 *                  is a palindrome using linked lists and iterators.
 */
package palindrometester;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;


public class PalindromeTester 
{
    public static void main(String[] args) 
    {
        File myFile;
        Scanner inFile = null;
        String word;
        LinkedList<String> possiblePal;
        HelperPal myPalHelp = new HelperPal();
        
        //try-catch block for reading file
        try
        {
            //open and scan file
            myFile = new File("candidates.txt");
            inFile = new Scanner(myFile);
            //read file in a while loop
            while (inFile.hasNext())
            {
                word = inFile.next();
                //call the linked list method for each string
                possiblePal = makeLinkedList(word);
                
                //call the helper method to see if the string is a palindrome
                if (myPalHelp.isPalindrome(possiblePal))
                {
                    System.out.println(word + " is a Palindrome.");
                }
                else
                {
                    System.out.println(word + " is NOT a Palindrome.");
                }
            }
        }
        //catch any exception
        catch (IOException e)
        {
            System.out.println("Sorry, wrong file.  Come back later.");
        }
        //finally to close file
        finally
        {
            if (inFile != null)
                inFile.close();
        }
    }
    
    //this method makes a linked list for each element in a string
    public static LinkedList<String> makeLinkedList(String word)
    {
        //create a local string array
        String[] wordArray;
        
        //create a new local linked list
        LinkedList<String> aLLWord = new LinkedList<String>();
        
        //use split("") to separate each element in array
        wordArray = word.split("");
        
        //for each element in the array add it to the end of the linked list
        for(int i = 0; i < wordArray.length; i++)
        {
            aLLWord.addLast(wordArray[i]);
        }
        //return linked list
        return aLLWord;
    }
}