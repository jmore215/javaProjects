/*
 * @author 5775423
 * 
 * Title: Programming Challenge 6
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program plays a lottery game with the user.
 */

package lotterygame;

public class LotteryGame 
{
    public static void main(String[] args) 
    {
        //create variable to store method that returns a value
        int matches;
        
        //create a new lottery ticket
        Lottery lotteryTicket = new Lottery();
        
        //call the getUsersPicks() method
        lotteryTicket.getUsersPicks();
        
        //call the checkLotteryMatch() method and store it into matches variable
        matches = lotteryTicket.checkLotteryMatch();
        
        //if- else if for 6, 5, 4, 3, or no matches
        //For a 6-digit match, display a message to the user that he/she will receive a grand prize of $1,000,000.
        if(matches == 6)
        {
            System.out.println("You will receive a grand prize of $1,000,000.");
        }
        //For a 5-digit match, display a message to the user that he/she will receive a prize of $50,000.
        else if(matches == 5)
        {
            System.out.println("You will receive a prize of $50,000.");
        }
        //For a 4-digit match, display a message to the user that he/she will receive a $2000 prize
        else if(matches == 4)
        {
            System.out.println("You will receive a $2000 prize.");
        }
        //For a 3-digit match, display a message to the user that he/she will receive a free Lottery ticket as the prize
        else if(matches == 3)
        {
            System.out.println("You will receive a free Lottery ticket as the prize.");
        }
        //If there are no matches, display the following message to the user:  "Sorry, no matches today.  Try again!"
        else if(matches == 0)
        {
            System.out.println("Sorry, no matches today. Try again!");
        }
    }
}
