/*
 * @author 5775423
 * 
 * Title: Programming Challenge 6
 * Semester: COP2250 - Fall 2018
 * Lecturer's Name: Charters
 * Description: This program plays a lottery game with the user.
 */

package lotterygame;

//import scanner and random
import java.util.Scanner;
import java.util.Random;

public class Lottery 
{
    //Create an array of six integers named lotteryNumbers 
    private int[] lotteryNumbers = new int[6];
    //Create another array of six integers named userLotteryPicks.
    private int[] userLotteryPicks = new int[6];
    
    //the Lottery constructor generates 6 unique numbers to be stored into the lotteryNumbers array
    public Lottery()
    {
        //create 2 int variables for random num and for a counter(j) set to 0 
        int ranNum;
        int j = 0;
        
        //create random object
        Random myRan = new Random();
        
        //do while j < 6
        do
        {
            //random number generator from 1 to 60
            ranNum = myRan.nextInt(60)+1;
            
            //have the very first number generated stored into the array
            if (j == 0) 
            {
                lotteryNumbers[j] = ranNum;
            }  
            
            //for loop: i starts at 0 and stops when j = 6
            for (int i = 0; i < j; i++) 
            {
                //while ran num generated is equal to any number in the array, then keep generating a random number 
                while(ranNum == lotteryNumbers[i])
                {
                    ranNum = myRan.nextInt(60)+1;   
                    i = 0;
                } 
            }
            //if j is not the first number generated, store it into the array
            if(j > 0)
                lotteryNumbers[j] = ranNum;
            //increment j by 1
            j++;
        }while(j < 6);      
    }
    
    //this method asks the user to enter 6 unique numbers between 1 - 60, which will be stored in the usersLotteryPicks array.
    public void getUsersPicks()
    {
        //display the lottery numbers generated in the constructor
        for(int i = 0; i < lotteryNumbers.length; i++)
        {
            System.out.println("Value in Lottery Array Position " + i + ": " + lotteryNumbers[i]);
        }
        
        //variable to store user input 
        int num;
        
        //Scanner object for user input
        Scanner keyboard = new Scanner(System.in);
        
        //for loop from 0 to the length of userLotteryPicks array
        for(int i = 0; i < userLotteryPicks.length; i++)
        {
            //ask the user to enter a unique number from 1 to 60 and store it
           System.out.println("Enter unique #" + i + " (from 1 to 60)");
           num = keyboard.nextInt();
            
           //store the first number that the user entered into the userLotteryPicks array
           if (i == 0) 
           {
               userLotteryPicks[i] = num;
           } 
           //a second for loop where j is 0 and goes to length of i
           for (int j = 0; j < i; j++) 
           {
               //while ran num generated is equal to any number in the array, ask them to enter a unique number not duplicate
                while(num == userLotteryPicks[j])
                {
                     System.out.println("(No Duplicates!)Enter unique #" + i + " (from 1 to 60)");
                     num = keyboard.nextInt();
                     
                     j = 0;
                }    
           }
           //store the number into the array
           userLotteryPicks[i] = num; 
        } 
    }
    
    //this method compares the 2 arrays and returns the number of digits that match. 
    public int checkLotteryMatch()
    {
        //set int variable called matches to 0
        int matches = 0;
        
        //for loop that starts at 0 and goes to the length of userLotteryPicks array
        for(int i = 0 ; i < userLotteryPicks.length; i++)
        {
            //inner for loop that starts at 0 and goes to the length of lotteryNumbers array
            for(int j = 0; j < lotteryNumbers.length; j++)
            {
                //if the number in userLotteryPicks matches the number in lotteryNumbers, add 1 to matches
                if(userLotteryPicks[i] == lotteryNumbers[j])
                {
                    matches++;
                } 
            }
        }
        //return matches
        return matches;
    }
}
