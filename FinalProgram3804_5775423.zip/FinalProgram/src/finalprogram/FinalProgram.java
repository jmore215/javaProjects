/*
 * @author 5775423
 * 
 * Title: FinalProgram3804_5775423
 * Semester: COP3804 - Spring 2019
 * Lecturer's Name: Charters
 * Description: This program uses linked lists, stacks, queues, and priority 
 *              queues with a poem.
 */
package finalprogram;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class FinalProgram 
{
    public static Scanner keyboard = new Scanner(System.in);
    
    public static void main(String[] args) 
    {
        //create variable to store user input
        String aWord = "";
        
        LinkedList<String> theList = createLLPoem();
        Stack<String> theStack = createStackPoem();
        Queue<String> theQueue = createQueuePoem();
        PriorityQueue<String> thePriorityQueue = createPriorityQueuePoem();
       
        //print what each method created
        System.out.println("Before...");
        System.out.println(theList);
        System.out.println(theStack);
        System.out.println(theQueue);
        System.out.println(thePriorityQueue);
      
        
        //ask the user what word to look out for and store it
        System.out.print("\nEnter any word in the poem: ");
        aWord = keyboard.nextLine();
        
        //call the methods that count the occurrence of the word
        int countLL = count(theList, aWord);
        int countStack = count(theStack, aWord);
        int countQueue = count(theQueue, aWord);
        int countPriorityQueue = count(thePriorityQueue, aWord);
     
        //show the word count for each method
        System.out.println( "\n" + aWord + " found in Linked List " + countLL + " times.");
        System.out.println(aWord + " found in Stack " + countStack + " times.");
        System.out.println(aWord + " found in Queue " + countQueue + " times.");
        System.out.println(aWord + " found in Priority Queue " + countPriorityQueue + " times.");
       
        //print the result of each method
        System.out.println("\nAfter...");
        System.out.println(theList);
        System.out.println(theStack);
        System.out.println(theQueue);
        System.out.println(thePriorityQueue);
    }
    
    //this method creates and returns a linked list
    public static LinkedList<String> createLLPoem()
    {
        //take the poem and put it into an array by separating each word
        String poem = "Hickory dickory dock The mouse ran up the clock The clock struck one and down he runs Hickory dickory dock";
        String[] poemArray = poem.split(" ");
        
        //create a linked list and iterator
        LinkedList<String> aLL = new LinkedList<String>();
        ListIterator<String> iter = aLL.listIterator();

        //put each word in the array into the iterator
        for(int i = 0; i < poemArray.length; i++)
        {
            iter.add(poemArray[i]);
        }
        
        //put each word in the iterator into the linked list
        while(iter.hasNext())
        {
            aLL.add(iter.next());
        }
        
        return aLL;
    }
    
    //this method creates and returns a stack
    public static Stack<String> createStackPoem()
    {
        //create a stack
        Stack<String> aStack = new Stack<String>();
        
        //take the poem and put it into an array by separating each word
        String poem = "Hickory dickory dock The mouse ran up the clock The clock struck one and down he runs Hickory dickory dock";
        String[] poemArray = poem.split(" ");
        
        //push each word in the array onto the stack
        for(int i = 0; i < poemArray.length; i++)
        {
            aStack.push(poemArray[i]);
        }
        
        return aStack;
    }
    
    //this method creates and returns a queue
    public static Queue<String> createQueuePoem()
    {
        //take the poem and put it into an array by separating each word
        String poem = "Hickory dickory dock The mouse ran up the clock The clock struck one and down he runs Hickory dickory dock";
        String[] poemArray = poem.split(" ");
        
        //create a queue
        Queue<String> aQueue = new LinkedList<String>();
        
        //add each word in the array into the queue
        for(int i = 0; i < poemArray.length; i++)
        {
            aQueue.add(poemArray[i]);
        }
    
        return aQueue;
    }
    
    //this method creates and returns a priority queue
    public static PriorityQueue<String> createPriorityQueuePoem()
    {
        //take the poem and put it into an array by separating each word
        String poem = "Hickory dickory dock The mouse ran up the clock The clock struck one and down he runs Hickory dickory dock";
        String[] poemArray = poem.split(" ");
        String aWord;
        //create a priority queue
        PriorityQueue<String> aPriorityQueue = new PriorityQueue<String>();
        
        //add each word in the array into the priority queue
        for(int i = 0; i < poemArray.length; i++)
        {
            aWord = poemArray[i];
            
            aPriorityQueue.add(aWord);
        }
        
        return aPriorityQueue;
    }
    
    //this method counts the occurences of the word in the linked list
    public static int count(LinkedList<String> theList, String word)
    {
        int wordCount = 0;
        
        //create an iterator
        ListIterator<String> iter = theList.listIterator();
        
        //for each word in the iterator...
        while(iter.hasNext())
        {
            //...count the occurences of the passed word
            if(iter.next().equalsIgnoreCase(word))
            {
                wordCount++;
            }
        }
        
        return wordCount;
    }
    
    //this method counts the occurences of the word in the stack
    public static int count(Stack<String> theStack, String word)
    {
        int wordCount = 0;
        
        //create a temporary stack
        Stack<String> tempStack = new Stack<String>();
        tempStack.addAll(theStack);
        
        //for each word in the stack...
        while(!tempStack.isEmpty())
        {
            //...count the occurences of the passed word
            if(tempStack.pop().equalsIgnoreCase(word))
            {
                wordCount++;
            }
        }
        return wordCount;
    }
    
    //this method counts the occurences of the word in the queue
    public static int count(Queue<String> theQueue, String word)
    {
        int wordCount = 0;
        
        //create a temporary queue
        Queue<String> tempQueue = new LinkedList<String>(theQueue);
        
        //for each word in the queue...
        while(!tempQueue.isEmpty())
        {
            //...count the occurences of the passed word
            if(tempQueue.remove().equalsIgnoreCase(word))
            {
                wordCount++;
            }
        }
        return wordCount;
    }
    
    //this method counts the occurences of the word in the priority queue
    public static int count(PriorityQueue<String> thePriorityQueue, String word)
    {
        int wordCount = 0;
        
        //create a temporary priority queue
        PriorityQueue<String> tempPriorityQueue = new PriorityQueue<String>(thePriorityQueue);
        
        //for each word in the priority queue...
        while(!tempPriorityQueue.isEmpty())
        {
            //...count the occurences of the passed word
            if(tempPriorityQueue.remove().equalsIgnoreCase(word))
            {
                wordCount++;
            }
        }
        return wordCount;
    }
}
